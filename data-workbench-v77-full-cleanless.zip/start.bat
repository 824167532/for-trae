@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ================================================
echo   Data Workbench v2.1
echo ================================================
echo.

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

:: Kill old process on port 8800
echo [*] Checking port 8800...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8800 ^| findstr LISTENING') do (
    echo [*] Killing old process: %%a
    taskkill /f /pid %%a >nul 2>&1
)
timeout /t 1 /nobreak >nul

:: Install Python deps
echo [*] Checking Python dependencies...
python -c "import fastapi, uvicorn, openpyxl, python_multipart, chardet" 2>nul
if %errorlevel% neq 0 (
    echo [*] Installing dependencies...
    pip install fastapi uvicorn openpyxl python-multipart chardet -q
)

:: Start
echo.
echo [OK] Service started: http://localhost:8800
echo [*] Close this window to stop
echo.
python start.py
pause
