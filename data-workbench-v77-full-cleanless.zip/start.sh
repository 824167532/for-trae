#!/bin/bash
# ================================================
#   Data Workbench v2.0 — Mac/Linux 终端启动
# ================================================

cd "$(dirname "$0")"

echo "================================================"
echo "  Data Workbench v2.0"
echo "================================================"
echo ""

if ! command -v python3 &>/dev/null; then
    echo "[ERROR] 未找到 Python3"
    exit 1
fi

lsof -ti:8800 2>/dev/null | xargs kill -9 2>/dev/null
sleep 1

echo "[*] 检查依赖..."
if ! python3 -c "import fastapi,uvicorn,openpyxl,python_multipart" 2>/dev/null; then
    echo "[*] 安装依赖（清华镜像）..."
    python3 -m pip install fastapi uvicorn openpyxl python_multipart \
        -i https://pypi.tuna.tsinghua.edu.cn/simple
fi

echo "[OK] 启动: http://localhost:8800"
sleep 1
open http://localhost:8800 2>/dev/null &
python3 start.py