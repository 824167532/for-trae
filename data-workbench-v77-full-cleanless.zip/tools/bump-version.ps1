﻿param(
    [string]$Note = "Change completed",
    [int]$TargetVersion = 0,
    [string]$ReleaseName = "",
    [switch]$NoHistory,
    [switch]$Package,
    [switch]$NoExtract
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$VersionFile = Join-Path $Root "VERSION.json"

function Write-Utf8File([string]$Path, [string]$Content) {
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Path, $Content, $utf8NoBom)
}

function Replace-InFile([string]$Path, [string]$Pattern, [string]$Replacement) {
    if (-not (Test-Path $Path)) { return }
    $text = Get-Content -Path $Path -Raw -Encoding UTF8
    $updated = [System.Text.RegularExpressions.Regex]::Replace($text, $Pattern, $Replacement)
    if ($updated -ne $text) {
        Write-Utf8File $Path $updated
    }
}

function Assert-ChildPath([string]$Path, [string]$Parent) {
    $fullPath = [System.IO.Path]::GetFullPath($Path)
    $fullParent = [System.IO.Path]::GetFullPath($Parent).TrimEnd([System.IO.Path]::DirectorySeparatorChar) + [System.IO.Path]::DirectorySeparatorChar
    if (-not $fullPath.StartsWith($fullParent, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to modify path outside release parent: $fullPath"
    }
}

if (Test-Path $VersionFile) {
    $state = Get-Content -Path $VersionFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $next = if ($TargetVersion -gt 0) { $TargetVersion } else { [int]$state.version + 1 }
} else {
    $state = [PSCustomObject]@{ history = @() }
    $next = if ($TargetVersion -gt 0) { $TargetVersion } else { 1 }
}

$label = "v$next"
$semver = "0.0.$next"
$timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:sszzz")
$entry = [PSCustomObject]@{
    version = $next
    label = $label
    semver = $semver
    updated_at = $timestamp
    note = $Note
}

$history = @()
if ($state.PSObject.Properties.Name -contains "history") {
    $history = @($state.history)
}
if (-not $NoHistory) {
    $history += $entry
}

$newState = [PSCustomObject]@{
    version = $next
    label = $label
    semver = $semver
    updated_at = $timestamp
    note = $Note
    history = $history
}
Write-Utf8File $VersionFile (($newState | ConvertTo-Json -Depth 10) + "`n")

Replace-InFile (Join-Path $Root "src\App.vue") "石板蓝\s*.\s*v\d+" "石板蓝 · $label"
Get-ChildItem -Path (Join-Path $Root "dist\assets") -Filter "*.js" -File -ErrorAction SilentlyContinue | ForEach-Object {
    Replace-InFile $_.FullName "石板蓝\s*.\s*v\d+" "石板蓝 · $label"
}
Get-ChildItem -Path (Join-Path $Root "backend") -Filter "*.py" -File -ErrorAction SilentlyContinue | ForEach-Object {
    Replace-InFile $_.FullName "后端模块\s*v\d+" "后端模块 $label"
}

$packagePath = Join-Path $Root "package.json"
if (Test-Path $packagePath) {
    $pkg = Get-Content -Path $packagePath -Raw -Encoding UTF8 | ConvertFrom-Json
    $pkg.version = $semver
    Write-Utf8File $packagePath (($pkg | ConvertTo-Json -Depth 10) + "`n")
}

$lockPath = Join-Path $Root "package-lock.json"
if (Test-Path $lockPath) {
    $lockText = Get-Content -Path $lockPath -Raw -Encoding UTF8
    $versionRegex = [regex]::new('("version"\s*:\s*")0\.0\.\d+(")')
    $lockText = $versionRegex.Replace($lockText, { param($match)
        $match.Groups[1].Value + $semver + $match.Groups[2].Value
    }, 1)

    $rootPackageRegex = [regex]::new('("packages"\s*:\s*\{\s*""\s*:\s*\{[^}]*?"version"\s*:\s*")0\.0\.\d+(")', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    $lockText = $rootPackageRegex.Replace($lockText, { param($match)
        $match.Groups[1].Value + $semver + $match.Groups[2].Value
    }, 1)
    Write-Utf8File $lockPath $lockText
}

if ($Package) {
    $parent = Split-Path $Root -Parent
    $folderName = Split-Path $Root -Leaf
    $releaseName = if ($ReleaseName) {
        $ReleaseName
    } elseif ($folderName -match "v\d+") {
        $folderName -replace "v\d+", $label
    } else {
        "$folderName-$label"
    }
    $zipPath = Join-Path $parent "$releaseName.zip"
    $extractPath = Join-Path $parent $releaseName

    Push-Location $parent
    try {
        Compress-Archive -Path ".\$folderName\*" -DestinationPath ".\$releaseName.zip" -Force
    } finally {
        Pop-Location
    }
    if (-not $NoExtract) {
        Assert-ChildPath $extractPath $parent
        if (Test-Path $extractPath) {
            Remove-Item -LiteralPath $extractPath -Recurse -Force
        }
        Push-Location $parent
        try {
            Expand-Archive -Path ".\$releaseName.zip" -DestinationPath ".\$releaseName" -Force
        } finally {
            Pop-Location
        }
        Write-Host "Version bumped to $label ($semver). Package: $zipPath. Extracted: $extractPath"
    } else {
        Write-Host "Version bumped to $label ($semver). Package: $zipPath"
    }
} else {
    Write-Host "Version bumped to $label ($semver)."
}

