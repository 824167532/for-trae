import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const oldJs = path.join(root, "dist", "assets", "index-v69-combo-rollover.js");
const newJs = path.join(root, "dist", "assets", "index-v70-output-signature-combo.js");
await fs.copyFile(oldJs, newJs);

let text = await fs.readFile(newJs, "utf8");
const from = "先按匹配键优先级从小到大找候选；命中组合关系时，B 表先反向识别组合，A 表在同 key 内完整凑组，完整组合优先；未凑齐的重复子产品会拿所有可能组合去和剩余 B 候选比较，取最像的一条。普通匹配也会顺延：同 key、同 A 相似度值、同 A 输出配置的重复行，不会反复抢同一条 B，而是按分数从高到低、B 表从上到下继续取下一条。";
const to = "先按匹配键优先级从小到大找候选；命中组合关系时，B 表先反向识别组合，A 表在同 key 内完整凑组，完整组合优先；未凑齐的重复子产品会拿所有可能组合去和剩余 B 候选比较，取最像的一条。普通匹配也会顺延：同 key、同 A 相似度值、同 A 输出配置的重复行，不会反复抢同一条 B，而是按分数从高到低、B 表从上到下继续取下一条。完整组合里，如果兑换项目、金额等 A 输出配置不同，会拆成不同组，各组可以命中同一条 B；输出配置相同的重复组才继续顺延。";
if (!text.includes(from)) {
  throw new Error("未找到需要替换的前端匹配策略文本");
}
text = text.replaceAll(from, to);
await fs.writeFile(newJs, text, "utf8");

const indexPath = path.join(root, "dist", "index.html");
let index = await fs.readFile(indexPath, "utf8");
index = index.replaceAll("/assets/index-v69-combo-rollover.js", "/assets/index-v70-output-signature-combo.js");
await fs.writeFile(indexPath, index, "utf8");
