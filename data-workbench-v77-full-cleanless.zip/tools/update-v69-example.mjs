import fs from "node:fs/promises";
import path from "node:path";
import { FileBlob, SpreadsheetFile } from "@oai/artifact-tool";

const root = process.cwd();
const publicExample = path.join(root, "public", "examples", "智能匹配映射表示例.xlsx");
const distExample = path.join(root, "dist", "examples", "智能匹配映射表示例.xlsx");

function getSheet(workbook, name, fallbackIndex) {
  try {
    return workbook.worksheets.getItem(name);
  } catch {
    return workbook.worksheets.getItemAt(fallbackIndex);
  }
}

function blankRows(rows, cols) {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => null));
}

function writeBlock(sheet, startCell, rows) {
  const cols = rows[0]?.length || 1;
  const clearCount = Math.max(rows.length + 8, 24);
  sheet.getRange(`${startCell}:${String.fromCharCode(64 + cols)}${clearCount}`).values = blankRows(clearCount, cols);
  sheet.getRange(`${startCell}:${String.fromCharCode(64 + cols)}${rows.length}`).values = rows;
}

const input = await FileBlob.load(publicExample);
const workbook = await SpreadsheetFile.importXlsx(input);

const rules = getSheet(workbook, "匹配规则", 0);
writeBlock(rules, "A1", [
  ["原始数据", "匹配键", "优先级", "OMC数据列", "相似度字段A", "相似度字段B", "相似度阈值"],
  ["激活时间", "key1", 1, "激活时间", "卡品名称", "OMC产品", 40],
  ["手机号码", "key1", 1, "手机号码", "", "", ""],
  ["账期", "key1", 1, "账期", "", "", ""],
  ["激活时间", "key2", 2, "激活时间", "", "", ""],
  ["OMC号码", "key2", 2, "OMC号码", "", "", ""],
  ["账期", "key2", 2, "账期", "", "", ""],
  ["激活时间", "key3", 3, "激活时间", "", "", ""],
  ["手机号码", "key3", 3, "手机号码", "", "", ""],
  ["手机号码", "key4", 4, "手机号码", "", "", ""],
]);

const outputs = getSheet(workbook, "输出配置", 1);
writeBlock(outputs, "A1", [
  ["输出列名"],
  ["激活时间"],
  ["手机号码"],
  ["OMC号码"],
  ["OMCID"],
  ["OMC产品"],
  ["卡品名称"],
  ["积分"],
  ["兑换项目"],
  ["账期"],
  ["similarity"],
  ["匹配来源键"],
  ["匹配相似度字段A"],
  ["匹配相似度字段B"],
  ["匹配相似度值A"],
  ["匹配相似度值B"],
  ["命中组合产品"],
  ["命中子产品"],
]);

const combos = getSheet(workbook, "组合关系", 2);
writeBlock(combos, "A1", [
  ["组合产品", "子产品1", "子产品2"],
  ["20元流量特惠包+5g新通话", "新通话-明星来电白银组合包B", "20元流量特惠包（150元充值满减券）"],
  ["特惠流量包+宠物洗护39.9元", "20元流量特惠包（150元充值满减券）", "宠物洗护服务包（流量版）"],
  ["上海移动20元随意换叠加包+18元饿了么轻享权益包", "20元随意换叠加包", "18元饿了么轻享权益包"],
  ["上海移动20元随意换叠加包+18元淘宝闪购轻享权益包", "20元随意换叠加包", "18元淘宝闪购轻享权益包"],
  ["35元流量月包娱乐版（电渠专属）", "20元12G流量月包", "咪咕视频钻石会员包月15元"],
  ["咪咕短剧情感优享包12个月合约（电渠）", "咪咕视频钻石会员包月15元", "咪咕短剧情感精品会员"],
  ["20元60G流量畅享包(W)12个月", "20元12G流量月包", ""],
]);

const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(publicExample);
await fs.mkdir(path.dirname(distExample), { recursive: true });
await fs.copyFile(publicExample, distExample);

const check = await workbook.inspect({
  kind: "table",
  range: "组合关系!A1:C8",
  include: "values",
  tableMaxRows: 8,
  tableMaxCols: 3,
});
console.log(check.ndjson);
