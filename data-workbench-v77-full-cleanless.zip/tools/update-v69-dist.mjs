import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const oldJs = path.join(root, "dist", "assets", "index-v68-key-combo.js");
const newJs = path.join(root, "dist", "assets", "index-v69-combo-rollover.js");
await fs.copyFile(oldJs, newJs);

let text = await fs.readFile(newJs, "utf8");
const replacements = [
  [
    "组合凑对范围：</strong>如果 <code data-v-f5dd9701>key1</code> 由月份+号码组成，系统只会在同一个月份+号码里凑对子产品；不同月份、不同号码、不同公司的产品不会互相组成组合。",
    "组合识别范围：</strong>如果 <code data-v-f5dd9701>key1</code> 由月份+号码组成，系统只会在同一个月份+号码里识别和凑对子产品；不同月份、不同号码、不同公司的产品不会互相组成组合，也不会共享 B 表候选。",
  ],
  [
    "系统会先在同一匹配键内凑齐子产品，凑齐时优先用完整组合产品；凑不齐时，单个子产品也可以作为线索去匹配同 key 范围内的 B 表组合产品。",
    "新版逻辑会先看同 key 下 B 表实际出现了哪些组合产品，再按组合关系回到 A 表里找子产品凑组；凑齐完整组合时优先占用对应 A 行和 B 行，剩余重复子产品再顺延匹配剩下的 B 组合候选。",
  ],
  [
    "<tr data-v-f5dd9701><td data-v-f5dd9701>20元60G流量畅享包(W)12个月</td><td data-v-f5dd9701>20元12G流量月包</td><td data-v-f5dd9701></td></tr>",
    "<tr data-v-f5dd9701><td data-v-f5dd9701>20元流量特惠包+5g新通话</td><td data-v-f5dd9701>新通话-明星来电白银组合包B</td><td data-v-f5dd9701>20元流量特惠包（150元充值满减券）</td></tr><tr data-v-f5dd9701><td data-v-f5dd9701>特惠流量包+宠物洗护39.9元</td><td data-v-f5dd9701>20元流量特惠包（150元充值满减券）</td><td data-v-f5dd9701>宠物洗护服务包（流量版）</td></tr><tr data-v-f5dd9701><td data-v-f5dd9701>20元60G流量畅享包(W)12个月</td><td data-v-f5dd9701>20元12G流量月包</td><td data-v-f5dd9701></td></tr>",
  ],
  [
    "先按匹配键优先级从小到大找候选；命中组合关系时，当前 key 下能凑齐多个子产品就优先使用完整组合产品，凑不齐才使用单子产品线索；同组多个 B 候选会按分数从高到低、B 表从上到下顺序分配。",
    "先按匹配键优先级从小到大找候选；命中组合关系时，B 表先反向识别组合，A 表在同 key 内完整凑组，完整组合优先；未凑齐的重复子产品会拿所有可能组合去和剩余 B 候选比较，取最像的一条。普通匹配也会顺延：同 key、同 A 相似度值、同 A 输出配置的重复行，不会反复抢同一条 B，而是按分数从高到低、B 表从上到下继续取下一条。",
  ],
];

for (const [from, to] of replacements) {
  if (!text.includes(from)) {
    throw new Error(`未找到需要替换的前端文本：${from.slice(0, 30)}`);
  }
  text = text.replaceAll(from, to);
}
await fs.writeFile(newJs, text, "utf8");

const indexPath = path.join(root, "dist", "index.html");
let index = await fs.readFile(indexPath, "utf8");
index = index.replaceAll("/assets/index-v68-key-combo.js", "/assets/index-v69-combo-rollover.js");
await fs.writeFile(indexPath, index, "utf8");
