# Versioning

Run this after each completed code change:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\bump-version.ps1 -Note "Short change note"
```

To also create a release zip and extracted release folder in the parent folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\bump-version.ps1 -Note "Short change note" -Package
```

To use a custom release folder and zip name:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\bump-version.ps1 -Note "Short change note" -Package -ReleaseName "data-workbench-v54-full-cleanless-multisim"
```

The script increments `VERSION.json`, updates the sidebar version, updates the built frontend bundle version, keeps `package.json` / `package-lock.json` aligned, creates a versioned zip, and extracts it to a matching versioned folder.
