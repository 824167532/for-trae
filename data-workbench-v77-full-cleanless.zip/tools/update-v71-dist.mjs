import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const oldJs = path.join(root, "dist", "assets", "index-v70-output-signature-combo.js");
const newJs = path.join(root, "dist", "assets", "index-v71-auth.js");
await fs.copyFile(oldJs, newJs);

let text = await fs.readFile(newJs, "utf8");
text = text.replaceAll("石板蓝 · v70", "石板蓝 · v71");
await fs.writeFile(newJs, text, "utf8");

const indexPath = path.join(root, "dist", "index.html");
let index = await fs.readFile(indexPath, "utf8");
index = index.replaceAll("/assets/index-v70-output-signature-combo.js", "/assets/index-v71-auth.js");
await fs.writeFile(indexPath, index, "utf8");
