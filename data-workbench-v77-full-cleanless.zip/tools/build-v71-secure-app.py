import hashlib
import os
import shutil
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT.parent
APP_ROOT = PARENT / "数据工作台-v71-授权应用版"
APP_DIR = APP_ROOT / "app"
RUNTIME_DIR = APP_ROOT / "runtime" / "python"
RUNTIME_CANDIDATES = [
    PARENT / "数据工作台-v70-应用版" / "runtime" / "python",
    Path(r"C:\Users\zlsjIOAC\.cache\codex-runtimes\codex-primary-runtime\dependencies\python"),
]
CRYPT_KEY = b"data-workbench-v71-secure-app-key"


def crypt(data: bytes) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < len(data):
        out.extend(hashlib.sha256(CRYPT_KEY + counter.to_bytes(8, "big")).digest())
        counter += 1
    return bytes(a ^ b for a, b in zip(data, out))


def copytree(src: Path, dst: Path):
    if dst.exists():
        shutil.rmtree(dst)
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc", "license.json")
    shutil.copytree(src, dst, ignore=ignore)


def build_backend_archive() -> bytes:
    with tempfile.TemporaryDirectory() as tmp:
        archive = Path(tmp) / "backend.zip"
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for file in (ROOT / "backend").glob("*.py"):
                zf.write(file, file.name)
        return archive.read_bytes()


def write_secure_start():
    content = f'''import hashlib
import os
import shutil
import sys
import tempfile
import threading
import time
import webbrowser
import zipfile
from pathlib import Path


APP_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = APP_DIR.parent
CRYPT_KEY = {CRYPT_KEY!r}


def crypt(data: bytes) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < len(data):
        out.extend(hashlib.sha256(CRYPT_KEY + counter.to_bytes(8, "big")).digest())
        counter += 1
    return bytes(a ^ b for a, b in zip(data, out))


def prepare_backend() -> Path:
    encrypted = APP_DIR / "backend.dwenc"
    temp_root = Path(tempfile.gettempdir()) / "data_workbench_v71_backend"
    backend_dir = temp_root / "backend"
    if temp_root.exists():
        shutil.rmtree(temp_root, ignore_errors=True)
    backend_dir.mkdir(parents=True, exist_ok=True)
    archive = temp_root / "backend.zip"
    archive.write_bytes(crypt(encrypted.read_bytes()))
    with zipfile.ZipFile(archive, "r") as zf:
        zf.extractall(backend_dir)
    try:
        archive.unlink()
    except OSError:
        pass
    return backend_dir


def open_browser():
    time.sleep(2)
    try:
        webbrowser.open("http://localhost:8800")
    except Exception:
        pass


def main():
    print("=" * 50)
    print("  数据工作台 v71 授权版")
    print("  授权校验 + 加密后端应用包")
    print("=" * 50)
    print()
    backend_dir = prepare_backend()
    os.environ["DATA_WORKBENCH_APP_DIR"] = str(APP_DIR)
    os.environ["DATA_WORKBENCH_DIST_DIR"] = str(APP_DIR / "dist")
    sys.path.insert(0, str(backend_dir))
    threading.Thread(target=open_browser, daemon=True).start()
    print("[OK] 服务启动: http://localhost:8800")
    print("[*] 首次使用会显示授权页面")
    print("[*] 关闭这个窗口即可停止应用")
    print()
    import uvicorn
    import main as backend_main

    uvicorn.run(backend_main.app, host="0.0.0.0", port=8800, reload=False, timeout_keep_alive=300)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\\n服务已停止")
    except Exception as exc:
        print(f"\\n[错误] 启动失败: {{exc}}")
        input("\\n按 Enter 退出...")
'''
    (APP_DIR / "start.py").write_text(content, encoding="utf-8")


def write_launcher():
    launcher = r'''@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 数据工作台 v71 授权版

echo ================================================
echo   数据工作台 v71 授权版
echo ================================================
echo.
echo 正在启动，请稍等...
echo 浏览器会自动打开：http://localhost:8800
echo 关闭这个窗口即可停止应用。
echo.

for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8800 ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>&1
)

"%~dp0runtime\python\python.exe" "%~dp0app\start.py"
pause
'''
    (APP_ROOT / "启动数据工作台.bat").write_text(launcher, encoding="utf-8")


def write_readme():
    readme = """# 数据工作台 v71 授权版

双击 `启动数据工作台.bat` 即可打开。

说明：
- 首次启动会显示机器码，需要输入授权码后才能使用。
- 授权码绑定当前电脑，并带有效期。
- 应用版不包含明文后端源码，后端会在启动时临时解密运行。
- 关闭启动窗口即可停止应用。
- 默认地址：http://localhost:8800
"""
    (APP_ROOT / "使用说明.txt").write_text(readme, encoding="utf-8")


def main():
    runtime_source = next((p for p in RUNTIME_CANDIDATES if p.exists()), None)
    if not runtime_source:
        raise RuntimeError("找不到可用 Python 运行环境")

    if APP_ROOT.exists():
        shutil.rmtree(APP_ROOT)
    APP_DIR.mkdir(parents=True, exist_ok=True)

    for name in ["dist", "public"]:
        copytree(ROOT / name, APP_DIR / name)
    for name in ["VERSION.json", "README.md"]:
        shutil.copy2(ROOT / name, APP_DIR / name)

    encrypted_backend = crypt(build_backend_archive())
    (APP_DIR / "backend.dwenc").write_bytes(encrypted_backend)
    write_secure_start()
    write_launcher()
    write_readme()
    copytree(runtime_source, RUNTIME_DIR)

    zip_path = PARENT / "数据工作台-v71-授权应用版.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for file in APP_ROOT.rglob("*"):
            if file.is_file():
                zf.write(file, file.relative_to(APP_ROOT))
    print(f"应用版已生成: {APP_ROOT}")
    print(f"压缩包已生成: {zip_path}")


if __name__ == "__main__":
    main()
