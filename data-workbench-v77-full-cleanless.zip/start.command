#!/bin/bash
# ================================================
#   Data Workbench v2.0 — Mac 双击启动
#   首次运行自动安装依赖（清华镜像加速）
# ================================================

cd "$(dirname "$0")"

echo "================================================"
echo "  Data Workbench v2.0"
echo "  Vue 3 + FastAPI"
echo "================================================"
echo ""

# 检查 Python
if ! command -v python3 &>/dev/null; then
    echo "[ERROR] 未找到 Python3，请先安装 Python 3.8+"
    echo "下载地址: https://www.python.org/downloads/"
    read -p "按 Enter 退出..."
    exit 1
fi

# 杀掉旧进程
echo "[*] 检查端口 8800..."
lsof -ti:8800 2>/dev/null | xargs kill -9 2>/dev/null
sleep 1

# 安装依赖（清华镜像加速）
echo "[*] 检查 Python 依赖..."
if ! python3 -c "import fastapi,uvicorn,openpyxl,python_multipart" 2>/dev/null; then
    echo "[*] 正在安装依赖（清华镜像）..."
    python3 -m pip install fastapi uvicorn openpyxl python_multipart \
        -i https://pypi.tuna.tsinghua.edu.cn/simple
    echo "[OK] 依赖安装完成"
else
    echo "[OK] 依赖已就绪"
fi

echo ""
echo "[OK] 服务启动: http://localhost:8800"
echo "[*] 关闭此窗口即可停止服务"
echo ""

# 打开浏览器
sleep 1
open http://localhost:8800 2>/dev/null &

# 启动服务
python3 start.py