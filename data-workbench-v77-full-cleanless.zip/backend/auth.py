import base64
import hashlib
import hmac
import json
import os
import platform
import uuid
from datetime import date, datetime, timezone
from pathlib import Path


PRODUCT_ID = "data-workbench-v71"
LICENSE_SECRET = b"data-workbench-v71-license-secret-2026-keep-private"


def _app_root() -> Path:
    override = os.environ.get("DATA_WORKBENCH_APP_DIR")
    if override:
        return Path(override).resolve()
    return Path(__file__).resolve().parent.parent


def license_path() -> Path:
    return _app_root() / "license.json"


def _safe_text(value) -> str:
    return str(value or "").strip().lower()


def _windows_machine_guid() -> str:
    try:
        import winreg

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            return _safe_text(value)
    except Exception:
        return ""


def get_machine_code() -> str:
    parts = [
        _safe_text(platform.node()),
        _safe_text(platform.system()),
        _safe_text(platform.machine()),
        _safe_text(uuid.getnode()),
        _windows_machine_guid(),
    ]
    raw = "|".join(part for part in parts if part)
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()
    core = digest[:20]
    return "-".join(core[i : i + 4] for i in range(0, len(core), 4))


def _b64_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64_decode(text: str) -> bytes:
    padding = "=" * (-len(text) % 4)
    return base64.urlsafe_b64decode((text + padding).encode("ascii"))


def _sign(payload_b64: str) -> str:
    digest = hmac.new(LICENSE_SECRET, payload_b64.encode("ascii"), hashlib.sha256).digest()
    return _b64_encode(digest)


def create_license_code(machine_code: str, days: int = 365) -> str:
    days = max(1, int(days or 365))
    expires = date.fromordinal(date.today().toordinal() + days).isoformat()
    payload = {
        "product": PRODUCT_ID,
        "machine_code": machine_code.strip().upper(),
        "expires": expires,
        "issued_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    payload_b64 = _b64_encode(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))
    return f"DW71-{payload_b64}.{_sign(payload_b64)}"


def parse_license_code(license_code: str) -> dict:
    code = (license_code or "").strip()
    if code.startswith("DW71-"):
        code = code[5:]
    if "." not in code:
        raise ValueError("授权码格式不正确")
    payload_b64, signature = code.split(".", 1)
    expected = _sign(payload_b64)
    if not hmac.compare_digest(signature, expected):
        raise ValueError("授权码签名无效")
    try:
        payload = json.loads(_b64_decode(payload_b64).decode("utf-8"))
    except Exception as exc:
        raise ValueError("授权码内容无法读取") from exc
    return payload


def validate_payload(payload: dict, machine_code: str | None = None) -> dict:
    current_machine = (machine_code or get_machine_code()).strip().upper()
    if payload.get("product") != PRODUCT_ID:
        raise ValueError("授权码产品不匹配")
    if str(payload.get("machine_code", "")).strip().upper() != current_machine:
        raise ValueError("授权码不属于当前电脑")
    expires_text = str(payload.get("expires", "")).strip()
    try:
        expires = date.fromisoformat(expires_text)
    except ValueError as exc:
        raise ValueError("授权码到期日期无效") from exc
    today = date.today()
    days_left = (expires - today).days
    if days_left < 0:
        raise ValueError("授权码已过期")
    return {
        "machine_code": current_machine,
        "expires_at": expires.isoformat(),
        "days_left": days_left,
    }


def read_license_file() -> dict | None:
    path = license_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def write_license_file(license_code: str, payload: dict) -> None:
    path = license_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    content = {
        "license_code": license_code.strip(),
        "payload": payload,
        "activated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    path.write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")


def get_auth_status() -> dict:
    machine_code = get_machine_code()
    saved = read_license_file()
    if not saved or not saved.get("license_code"):
        return {
            "authorized": False,
            "machine_code": machine_code,
            "expires_at": "",
            "days_left": 0,
            "message": "当前电脑未授权",
        }
    try:
        payload = parse_license_code(saved.get("license_code", ""))
        valid = validate_payload(payload, machine_code)
        return {
            "authorized": True,
            "machine_code": machine_code,
            "expires_at": valid["expires_at"],
            "days_left": valid["days_left"],
            "message": "授权有效",
        }
    except ValueError as exc:
        return {
            "authorized": False,
            "machine_code": machine_code,
            "expires_at": "",
            "days_left": 0,
            "message": str(exc),
        }


def activate_license(license_code: str) -> dict:
    machine_code = get_machine_code()
    payload = parse_license_code(license_code)
    valid = validate_payload(payload, machine_code)
    write_license_file(license_code, payload)
    return {
        "authorized": True,
        "machine_code": machine_code,
        "expires_at": valid["expires_at"],
        "days_left": valid["days_left"],
        "message": "授权成功",
    }


def render_auth_page(status: dict) -> str:
    status_json = json.dumps(status, ensure_ascii=False)
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>数据工作台授权</title>
  <style>
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; min-height: 100vh; display: grid; place-items: center; background: #f8fafc; color: #1e293b; font-family: "Microsoft YaHei", -apple-system, BlinkMacSystemFont, sans-serif; }}
    body::before {{ content: ""; position: fixed; inset: 0; background-image: radial-gradient(circle, #cbd5e1 0.6px, transparent 0.6px); background-size: 20px 20px; opacity: .55; }}
    .panel {{ position: relative; width: min(620px, calc(100vw - 32px)); background: #fff; border: 1px solid #dbe3ef; border-radius: 12px; box-shadow: 0 18px 40px rgba(15,23,42,.12); padding: 28px; }}
    h1 {{ margin: 0 0 8px; font-size: 24px; }}
    p {{ margin: 0 0 18px; color: #475569; line-height: 1.7; }}
    label {{ display: block; margin: 18px 0 8px; font-weight: 700; }}
    .machine {{ display: flex; gap: 10px; align-items: center; }}
    code {{ flex: 1; display: block; padding: 12px; border-radius: 8px; background: #f1f5f9; border: 1px solid #cbd5e1; font-size: 16px; letter-spacing: .08em; color: #0f172a; word-break: break-all; }}
    textarea {{ width: 100%; min-height: 120px; resize: vertical; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; font: inherit; outline: none; }}
    textarea:focus {{ border-color: #3b82f6; box-shadow: 0 0 0 3px rgba(59,130,246,.12); }}
    button {{ border: 0; border-radius: 8px; padding: 11px 16px; font-weight: 700; cursor: pointer; background: #334155; color: #fff; }}
    button.primary {{ margin-top: 14px; width: 100%; background: #2563eb; }}
    .hint {{ margin-top: 12px; padding: 12px; border-radius: 8px; background: #eff6ff; color: #1d4ed8; }}
    .error {{ background: #fef2f2; color: #b91c1c; }}
    .ok {{ background: #f0fdf4; color: #047857; }}
  </style>
</head>
<body>
  <main class="panel">
    <h1>数据工作台需要授权</h1>
    <p>请把下面的机器码发给管理员，获取当前电脑专用的授权码。授权成功后，这台电脑在有效期内可以离线使用。</p>
    <label>当前机器码</label>
    <div class="machine">
      <code id="machine"></code>
      <button type="button" onclick="copyMachine()">复制</button>
    </div>
    <label for="license">授权码</label>
    <textarea id="license" placeholder="请粘贴授权码"></textarea>
    <button class="primary" type="button" onclick="activate()">激活并进入</button>
    <div id="message" class="hint"></div>
  </main>
  <script>
    const initialStatus = {status_json};
    const machineEl = document.getElementById('machine');
    const msgEl = document.getElementById('message');
    machineEl.textContent = initialStatus.machine_code || '';
    msgEl.textContent = initialStatus.message || '当前电脑未授权';
    if (initialStatus.message && initialStatus.message !== '当前电脑未授权') msgEl.className = 'hint error';
    async function refreshStatus() {{
      const res = await fetch('/api/auth/status', {{ cache: 'no-store' }});
      const data = await res.json();
      machineEl.textContent = data.machine_code || '';
      if (data.authorized) location.href = '/';
      return data;
    }}
    async function copyMachine() {{
      await navigator.clipboard.writeText(machineEl.textContent);
      msgEl.className = 'hint ok';
      msgEl.textContent = '机器码已复制';
    }}
    async function activate() {{
      const licenseCode = document.getElementById('license').value.trim();
      if (!licenseCode) {{
        msgEl.className = 'hint error';
        msgEl.textContent = '请先粘贴授权码';
        return;
      }}
      msgEl.className = 'hint';
      msgEl.textContent = '正在校验授权码...';
      try {{
        const res = await fetch('/api/auth/activate', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body: JSON.stringify({{ license_code: licenseCode }}),
        }});
        const data = await res.json().catch(() => ({{ detail: '授权失败' }}));
        if (!res.ok) throw new Error(data.detail || '授权失败');
        msgEl.className = 'hint ok';
        msgEl.textContent = `授权成功，到期时间：${{data.expires_at}}，剩余 ${{data.days_left}} 天`;
        setTimeout(() => location.href = '/', 800);
      }} catch (err) {{
        msgEl.className = 'hint error';
        msgEl.textContent = err.message || '授权失败';
      }}
    }}
    refreshStatus().catch(() => null);
  </script>
</body>
</html>"""
