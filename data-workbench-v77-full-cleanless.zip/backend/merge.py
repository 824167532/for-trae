"""
表格合并后端模块
"""
import os
import uuid
import threading
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
import openpyxl
import csv
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

# 临时目录
TMP_DIR = Path("/tmp/data-workbench")
TMP_DIR.mkdir(parents=True, exist_ok=True)

# 任务存储
tasks = {}
tasks_lock = threading.Lock()


# ===== 数据模型 =====


class FileInfo(BaseModel):
    id: str
    name: str
    tmp_path: str
    sheets: list = []


class MergeConfig(BaseModel):
    files: list[FileInfo] = []
    file_order: list = []
    do_merge: bool = True
    add_source_col: bool = True
    source_col_name: str = "数据来源"
    col_order: str = "custom"
    custom_columns: list = []


# ===== 工具函数 =====

def _count_cjk_chars(text: str) -> int:
    """统计文本中 CJK 统一表意文字的数量（U+4E00-U+9FFF）"""
    return sum(1 for ch in text if '\u4e00' <= ch <= '\u9fff')


def _detect_csv_encoding(filepath: str) -> str:
    """检测 CSV 文件编码（读取更多字节提高准确率）"""
    import codecs
    import os
    file_size = os.path.getsize(filepath)
    # 读取更多字节：小文件全读，大文件读前 64KB
    read_size = min(file_size, 65536)
    with open(filepath, "rb") as f:
        raw = f.read(read_size)
    # 先看 BOM
    if raw[:3] == b"\xef\xbb\xbf":
        return "utf-8-sig"
    if raw[:2] == b"\xff\xfe":
        return "utf-16-le"
    if raw[:2] == b"\xfe\xff":
        return "utf-16-be"
    # 尝试用 chardet
    chardet_enc = None
    try:
        import chardet
        result = chardet.detect(raw)
        if result["encoding"] and result["confidence"] > 0.7:
            enc = result["encoding"].lower()
            if enc in ("gb2312", "gbk", "gb18030"):
                return "gbk"
            chardet_enc = enc
    except ImportError:
        pass

    # 核心策略：对 chardet 返回 utf-8 的结果做二次验证
    # 因为 GBK 字节流经常被 chardet 误判为 utf-8（解码不报错但变成乱码）
    candidates = []
    for enc in ["utf-8-sig", "utf-8", "gb18030", "gbk"]:
        try:
            codecs.lookup(enc)
            decoded = raw.decode(enc)
            cjk = _count_cjk_chars(decoded)
            candidates.append((enc, cjk, decoded))
        except (UnicodeDecodeError, LookupError):
            continue

    if not candidates:
        return "utf-8"

    # 如果 GBK 解码出 CJK 字符，且不少于 UTF-8 的结果 → 用 GBK
    # （UTF-8 解码 GBK 字节不报错但产生乱码，GBK 解码 UTF-8 字节会报错，
    #   所以 GBK 能成功解码且出中文，就大概率是 GBK 文件）
    gbk_candidate = next((c for c in candidates if c[0] == "gbk"), None)
    utf8_candidate = next((c for c in candidates if c[0] in ("utf-8", "utf-8-sig")), None)
    if gbk_candidate and gbk_candidate[1] > 0:
        if not utf8_candidate or gbk_candidate[1] >= utf8_candidate[1]:
            return "gbk"

    # 选 CJK 字符最多的编码（中文文件更可靠）
    best = max(candidates, key=lambda x: x[1])
    if best[1] > 0:
        return best[0]

    # 没有中文，用 chardet 结果或第一个成功的编码
    return chardet_enc or candidates[0][0]


def _open_csv_safe(filepath: str):
    """尝试用多种编码打开 CSV 文件，返回 (file_obj, encoding)
    
    策略：对所有候选编码解码前 10 行，比较 CJK 字符数量，
    选 CJK 最多的编码。这能有效防止 GBK 字节被 UTF-8 静默误读
    （GBK→UTF-8 乱码虽然也含 CJK，但数量通常少于正确解码）。
    """
    detected = _detect_csv_encoding(filepath)

    # 构建候选列表：检测到的编码 + 常见中文编码 + 其他东亚编码
    candidates = []
    for enc in [detected, "gbk", "gb18030", "utf-8-sig", "utf-8",
                "utf-16-le", "utf-16-be", "big5", "big5hkscs"]:
        if enc not in candidates:
            candidates.append(enc)

    best_file = None
    best_enc = None
    best_cjk = -1

    for enc in candidates:
        try:
            f = open(filepath, "r", encoding=enc)
            sample_lines = []
            for _ in range(50):
                line = f.readline()
                if not line:
                    break
                sample_lines.append(line)
            f.seek(0)
            sample = "".join(sample_lines)

            # 含替换字符 → 编码不对
            if '\ufffd' in sample:
                f.close()
                continue

            cjk = _count_cjk_chars(sample)
            if cjk > best_cjk:
                if best_file:
                    best_file.close()
                best_file = f
                best_enc = enc
                best_cjk = cjk
            else:
                f.close()
        except (UnicodeDecodeError, LookupError):
            continue

    if best_file:
        logger.info(f"CSV 编码检测: {best_enc} (CJK字符数={best_cjk})")
        return best_file, best_enc

    # 所有编码都失败，可能是纯二进制文件
    logger.warning(f"CSV 编码检测失败，所有候选编码均无法解码: {filepath}")
    return open(filepath, "r", encoding="latin-1"), "latin-1"


def parse_csv_meta(filepath: str):
    """解析 CSV 文件，返回元数据 + 前 100 行预览（极速）"""
    f, encoding = _open_csv_safe(filepath)
    with f:
        reader = csv.reader(f)
        try:
            first_row = next(reader)
        except StopIteration:
            return []
        headers = [str(h or "").strip() or f"Column_{i+1}" for i, h in enumerate(first_row)]
        preview_rows = []
        for row in reader:
            vals = [str(v or "") for v in row]
            if any(v.strip() for v in vals):
                preview_rows.append(vals)
                if len(preview_rows) >= 100:
                    break

    # 检测是否为二进制垃圾内容
    if preview_rows:
        sample = "".join(str(v) for row in preview_rows[:3] for v in row)
        if len(sample) > 10:
            # 统计 C1 控制字符 (0x80-0x9F)，这些在正常文本中极少出现
            c1_count = sum(1 for ch in sample if '\x80' <= ch <= '\x9f')
            if c1_count > len(sample) * 0.1:
                raise ValueError(
                    f"文件内容异常，可能不是文本 CSV 文件（检测到大量控制字符）。"
                    f"请确认文件编码是否正确，或尝试用 Excel 另存为 UTF-8 CSV。"
                )

    return [{
        "name": "Sheet1",
        "headers": headers,
        "row_count": None,
        "preview_rows": preview_rows,
    }]


def parse_csv_data(filepath: str):
    """解析 CSV 文件全部数据"""
    f, encoding = _open_csv_safe(filepath)
    with f:
        reader = csv.reader(f)
        try:
            first_row = next(reader)
        except StopIteration:
            return [], []
        headers = [str(h or "").strip() or f"Column_{i+1}" for i, h in enumerate(first_row)]
        data_rows = []
        for row in reader:
            vals = [str(v or "") for v in row]
            if any(v.strip() for v in vals):
                data_rows.append(vals)
    return headers, data_rows


def parse_excel_meta(filepath: str):
    """解析 Excel 文件，返回元数据 + 前 100 行预览（极速）"""
    wb = openpyxl.load_workbook(filepath, data_only=False, read_only=True)
    sheets = []
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows_iter = ws.iter_rows(values_only=True)
        try:
            first_row = next(rows_iter)
        except StopIteration:
            continue
        headers = []
        for i, val in enumerate(first_row):
            h = str(val or "").strip()
            if not h:
                h = f"Column_{i + 1}"
            headers.append(h)
        # 仅取前 100 行预览，避免上传阶段长时间阻塞
        preview_rows = []
        for row in rows_iter:
            vals = []
            has_content = False
            for val in row:
                if val is None:
                    val = ""
                else:
                    val = str(val)
                if val.strip():
                    has_content = True
                vals.append(val)
            if has_content:
                preview_rows.append(vals)
                if len(preview_rows) >= 100:
                    break
        sheets.append({
            "name": sheet_name,
            "headers": headers,
            "row_count": None,  # 极速模式：上传阶段不全量计数
            "preview_rows": preview_rows,
        })
    wb.close()
    return sheets


def parse_excel_data(filepath: str, sheet_name: str):
    """解析指定 sheet 的数据（流式读取，不全部加载到内存）"""
    wb = openpyxl.load_workbook(filepath, data_only=False, read_only=True)
    ws = wb[sheet_name]
    rows_iter = ws.iter_rows(values_only=True)
    try:
        first_row = next(rows_iter)
    except StopIteration:
        wb.close()
        return [], []
    headers = []
    for i, val in enumerate(first_row):
        h = str(val or "").strip()
        if not h:
            h = f"Column_{i + 1}"
        headers.append(h)
    data_rows = []
    for row in rows_iter:
        vals = []
        has_content = False
        for val in row:
            if val is None:
                val = ""
            else:
                val = str(val)
            if val.strip():
                has_content = True
            vals.append(val)
        if has_content:
            data_rows.append(vals)
    wb.close()
    return headers, data_rows


def get_column_order(all_headers_set, col_order, custom_columns, source_col_name=None):
    """确定列顺序，来源列始终置顶"""
    all_cols = list(all_headers_set)
    if col_order == "appearance":
        ordered = all_cols
    elif col_order == "alphabetical":
        ordered = sorted(all_cols, key=lambda x: x.lower())
    elif col_order == "custom":
        if custom_columns:
            ordered = [c for c in custom_columns if c in all_headers_set]
        else:
            ordered = all_cols
    else:
        ordered = all_cols
    # 来源列始终置顶
    if source_col_name and source_col_name in ordered:
        ordered = [c for c in ordered if c != source_col_name]
        ordered.insert(0, source_col_name)
    return ordered


def _is_really_xlsx(filepath: str) -> bool:
    """通过文件头判断是否为 xlsx（ZIP 格式）"""
    try:
        with open(filepath, "rb") as f:
            return f.read(2) == b"PK"
    except Exception:
        return filepath.lower().endswith(".xlsx")


def write_xlsx(columns, rows, filepath):
    """写入 XLSX 文件"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "合并结果"
    for ci, col in enumerate(columns, 1):
        ws.cell(row=1, column=ci, value=col)
    for ri, row in enumerate(rows, 2):
        for ci, col in enumerate(columns, 1):
            ws.cell(row=ri, column=ci, value=row.get(col, ""))
    wb.save(filepath)
    wb.close()


# ===== API 路由 =====

@router.post("/upload")
async def upload_files(files: list[UploadFile] = File(...)):
    """上传并解析文件（自动检测真实文件类型，不只看扩展名）"""
    result = []
    for f in files:
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in (".xlsx", ".csv"):
            if ext == ".xls":
                raise HTTPException(400, "暂不支持 .xls，请先另存为 .xlsx 后再上传")
            raise HTTPException(400, f"不支持的文件类型: {ext}")

        tmp_path = TMP_DIR / f"{uuid.uuid4()}{ext}"

        # 流式写入文件，同时检测真实类型
        total_size = 0
        magic_bytes = b""
        try:
            with open(tmp_path, "wb") as tmpf:
                first_chunk = True
                while True:
                    chunk = await f.read(1024 * 1024)  # 每次 1MB
                    if not chunk:
                        break
                    if first_chunk:
                        magic_bytes = chunk[:8]
                        first_chunk = False
                    tmpf.write(chunk)
                    total_size += len(chunk)
                    if total_size > 100 * 1024 * 1024:  # 100MB 限制
                        tmp_path.unlink(missing_ok=True)
                        raise HTTPException(400, f"文件过大: {f.filename}（超过 100MB 限制）")
        except HTTPException:
            raise
        except Exception as e:
            tmp_path.unlink(missing_ok=True)
            raise HTTPException(400, f"文件读取失败 {f.filename}: {str(e)}")

        # 检测真实文件类型（PK 开头 = ZIP = .xlsx）
        real_ext = ext
        if magic_bytes[:2] == b"PK":
            # ZIP 压缩包 → 实际是 .xlsx
            if ext == ".csv":
                logger.info(f"文件 {f.filename} 扩展名为 .csv 但实际是 .xlsx，自动切换解析方式")
                real_ext = ".xlsx"
                # 重命名临时文件，让 openpyxl 能正常打开
                new_path = tmp_path.with_suffix(".xlsx")
                tmp_path.rename(new_path)
                tmp_path = new_path
        elif ext == ".xlsx" and magic_bytes[:2] != b"PK":
            # 扩展名是 .xlsx 但不是 ZIP → 可能是 CSV 改的名
            logger.info(f"文件 {f.filename} 扩展名为 .xlsx 但不像 ZIP，尝试按 CSV 解析")
            real_ext = ".csv"

        try:
            if real_ext == ".csv":
                sheets = parse_csv_meta(str(tmp_path))
            else:
                sheets = parse_excel_meta(str(tmp_path))
            result.append({
                "id": str(uuid.uuid4()),
                "name": f.filename,
                "sheets": sheets,
                "tmp_path": str(tmp_path),
            })
        except Exception as e:
            tmp_path.unlink(missing_ok=True)
            raise HTTPException(400, f"解析失败 {f.filename}: {str(e)}")

    return {"files": result}


@router.post("/apply")
async def apply_merge(config: MergeConfig):
    """应用合并配置"""
    task_id = str(uuid.uuid4())
    with tasks_lock:
        tasks[task_id] = {"status": "processing", "current": 0, "total": 0, "message": ""}

    thread = threading.Thread(target=process_merge, args=(task_id, config))
    thread.start()

    return {"task_id": task_id}


def process_merge(task_id: str, config: MergeConfig):
    """后台处理合并"""
    try:
        # 按 file_order 排序文件
        file_map = {f.id: f for f in config.files}
        ordered_files = []
        for fid in config.file_order:
            if fid in file_map:
                ordered_files.append(file_map[fid])

        if not ordered_files:
            raise ValueError("没有可处理的文件")

        # 读取所有文件数据
        all_rows = []
        all_headers_set = set()
        total_steps = len(ordered_files) + 1  # 读取 + 写入
        with tasks_lock:
            tasks[task_id]["total"] = total_steps

        step = 0

        for fi, file_info in enumerate(ordered_files):
            if not os.path.exists(file_info.tmp_path):
                continue
            source_name = file_info.name
            is_csv = not _is_really_xlsx(file_info.tmp_path)

            for sheet_meta in file_info.sheets:
                if is_csv:
                    headers, data_rows = parse_csv_data(file_info.tmp_path)
                else:
                    headers, data_rows = parse_excel_data(file_info.tmp_path, sheet_meta["name"])
                for h in headers:
                    all_headers_set.add(h)

                for row_vals in data_rows:
                    row_dict = {}
                    for ci, h in enumerate(headers):
                        row_dict[h] = row_vals[ci] if ci < len(row_vals) else ""
                    # 添加来源列（可选）
                    if config.do_merge and config.add_source_col:
                        row_dict[config.source_col_name] = source_name
                        all_headers_set.add(config.source_col_name)
                    all_rows.append(row_dict)

            step += 1
            with tasks_lock:
                tasks[task_id]["current"] = step

        if not all_rows:
            raise ValueError("所有文件均为空")

        # 确定列顺序
        columns = get_column_order(
            all_headers_set,
            config.col_order,
            config.custom_columns,
            config.source_col_name if config.do_merge and config.add_source_col else None,
        )

        # 生成结果文件
        result_path = TMP_DIR / f"{task_id}_result.xlsx"

        if config.do_merge:
            # 合并模式：所有数据写入一个 sheet
            write_xlsx(columns, all_rows, str(result_path))
            filename = "合并结果.xlsx"
        else:
            # 独立模式：每个选中的子表一个 sheet
            wb = openpyxl.Workbook()
            wb.remove(wb.active)
            for file_info in ordered_files:
                if not os.path.exists(file_info.tmp_path):
                    continue
                is_csv = not _is_really_xlsx(file_info.tmp_path)
                selected_sheet_names = set(s["name"] for s in file_info.sheets)
                for sheet_meta in file_info.sheets:
                    if sheet_meta["name"] not in selected_sheet_names:
                        continue
                    if is_csv:
                        headers, data_rows = parse_csv_data(file_info.tmp_path)
                    else:
                        headers, data_rows = parse_excel_data(file_info.tmp_path, sheet_meta["name"])
                    ws = wb.create_sheet(title=f"{file_info.name}_{sheet_meta['name']}"[:31])
                    for ci, h in enumerate(headers, 1):
                        ws.cell(row=1, column=ci, value=h)
                    for ri, row_vals in enumerate(data_rows, 2):
                        for ci, val in enumerate(row_vals, 1):
                            ws.cell(row=ri, column=ci, value=val)
            wb.save(str(result_path))
            filename = "独立输出.xlsx"

        step += 1
        with tasks_lock:
            tasks[task_id]["current"] = step

        # 预览数据（前100行）
        preview_rows = []
        for row in all_rows[:100]:
            preview_rows.append({col: row.get(col, "") for col in columns})

        with tasks_lock:
            tasks[task_id].update({
                "status": "completed",
                "result_path": str(result_path),
                "filename": filename,
                "columns": columns,
                "rows": preview_rows,
                "total": total_steps,
            })

    except Exception as e:
        with tasks_lock:
            tasks[task_id].update({
                "status": "error",
                "message": str(e),
            })


@router.get("/status/{task_id}")
async def get_status(task_id: str):
    """获取任务状态"""
    with tasks_lock:
        task = tasks.get(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    resp = {
        "status": task["status"],
        "current": task.get("current", 0),
        "total": task.get("total", 0),
    }

    if task["status"] == "completed":
        resp.update({
            "columns": task.get("columns", []),
            "rows": task.get("rows", []),
            "filename": task.get("filename", "result.xlsx"),
        })
    elif task["status"] == "error":
        resp["message"] = task.get("message", "未知错误")

    return resp


@router.get("/download/{task_id}")
async def download_result(task_id: str):
    """下载结果文件"""
    with tasks_lock:
        task = tasks.get(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")
    if task["status"] != "completed":
        raise HTTPException(400, "任务尚未完成")

    result_path = task.get("result_path")
    if not result_path or not os.path.exists(result_path):
        raise HTTPException(404, "结果文件不存在")

    filename = task.get("filename", "result.xlsx")
    return FileResponse(
        result_path,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=filename,
    )
