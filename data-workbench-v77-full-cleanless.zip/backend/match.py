"""
智能匹配后端模块 v71
- 使用 rapidfuzz 相似度计算
- B 表预分组加速匹配
- A 表列优先（同名列不会被 B 覆盖）
- 输出列顺序遵循输出配置
- 相似度低于阈值整行黄色高亮
"""
import os
import re
import uuid
import threading
from pathlib import Path
from collections import defaultdict
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
import pandas as pd
import numpy as np
from openpyxl import load_workbook
from rapidfuzz import fuzz, process
from openpyxl.styles import PatternFill

YELLOW_FILL = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
SIMILARITY_COLUMNS = {"similarity", "匹配分数"}
SIMILARITY_DETAIL_OUTPUT_COLUMNS = [
    "匹配相似度字段A",
    "匹配相似度字段B",
    "匹配相似度值A",
    "匹配相似度值B",
]
SIMILARITY_DETAIL_COLUMNS = set(SIMILARITY_DETAIL_OUTPUT_COLUMNS)
COMBO_OUTPUT_COLUMNS = ["命中组合产品", "命中子产品"]
B_SUFFIX_POLICY_COLUMN = "B后缀处理"
B_SUFFIX_POLICIES = {
    "无后缀": "strip",
    "有后缀": "keep",
}

router = APIRouter()

TMP_DIR = Path("/tmp/data-workbench")
TMP_DIR.mkdir(parents=True, exist_ok=True)

tasks = {}
tasks_lock = threading.Lock()


def clean_cell(value):
    v = str(value).strip()
    return "" if not v or v.lower() == "nan" else v


def output_cell(value):
    if value is None:
        return ""
    return clean_cell(value)


def normalize_match_text(value):
    return clean_cell(value).lower()


def clean_b_match_value(value):
    text = clean_cell(value)
    if "@" in text:
        text = text.split("@", 1)[0].strip()
    return text


def build_b_similarity_choices(value, policy):
    full_value = clean_cell(value)
    stripped_value = clean_b_match_value(value)
    if policy == "keep":
        return [{"value": normalize_match_text(full_value), "output": full_value}]
    return [{"value": normalize_match_text(stripped_value), "output": stripped_value}]


def normalize_column_name(value):
    if value is None:
        return ""
    text = str(value).replace("\ufeff", "").replace("\u200b", "").strip()
    return text


def append_missing(columns, extra_columns):
    for col in extra_columns:
        if col not in columns:
            columns.append(col)
    return columns


# ===================== 相似度计算 =====================
def compute_similarity(str1, str2):
    if pd.isna(str1) or pd.isna(str2) or str1 == "" or str2 == "":
        return 0
    s1, s2 = str(str1).strip(), str(str2).strip()
    if s1 == s2:
        return 100
    return fuzz.WRatio(s1, s2)


# ===================== 解析输出配置 =====================
def parse_output_config(filepath):
    try:
        with pd.ExcelFile(filepath) as xl:
            if "输出配置" not in xl.sheet_names:
                return None
            df = pd.read_excel(xl, sheet_name="输出配置", dtype=str)
        if "输出列名" not in df.columns:
            return None
        cols = []
        for _, row in df.iterrows():
            c = str(row["输出列名"]).strip()
            if c and c != "nan":
                cols.append(c)
        return cols if cols else None
    except Exception:
        return None


# ===================== 解析组合关系 =====================
def parse_combo_relations(filepath):
    with pd.ExcelFile(filepath) as xl:
        if "组合关系" not in xl.sheet_names:
            return {}, [], False
        df = pd.read_excel(xl, sheet_name="组合关系", dtype=str)

    if "组合产品" not in df.columns:
        raise ValueError("组合关系缺少必要列: 组合产品")

    child_cols = [c for c in df.columns if str(c).strip().startswith("子产品")]
    if not child_cols:
        raise ValueError("组合关系至少需要一列子产品，例如: 子产品1")

    combo_lookup = defaultdict(list)
    combo_rules = []
    for row_order, row in df.iterrows():
        combo = clean_cell(row.get("组合产品", ""))
        if not combo:
            continue
        terms = [combo]
        children = []
        for col in child_cols:
            child = clean_cell(row.get(col, ""))
            if child:
                terms.append(child)
                children.append(child)

        if children:
            combo_rules.append({
                "combo": combo,
                "children": children,
                "child_keys": {normalize_match_text(child) for child in children},
                "combo_key": normalize_match_text(combo),
                "order": row_order,
            })

        for term in terms:
            term_key = normalize_match_text(term)
            if term_key:
                combo_lookup[term_key].append({
                    "combo": combo,
                    "child": term,
                    "order": row_order,
                })

    return dict(combo_lookup), combo_rules, bool(combo_lookup)


# ===================== 映射表解析 =====================
def parse_mapping(filepath):
    df = pd.read_excel(filepath, dtype=str, sheet_name=0)
    required = {"原始数据", "匹配键", "优先级", "OMC数据列"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"映射表缺少必要列: {missing}")

    b_suffix_policy = "strip"
    if B_SUFFIX_POLICY_COLUMN in df.columns:
        for raw in df[B_SUFFIX_POLICY_COLUMN]:
            value = clean_cell(raw)
            if not value:
                continue
            if value not in B_SUFFIX_POLICIES:
                raise ValueError(f"{B_SUFFIX_POLICY_COLUMN}只支持填写：无后缀、有后缀")
            b_suffix_policy = B_SUFFIX_POLICIES[value]
            break

    # 相似度字段规则：最多允许一组；不填写时只按匹配键输出。
    similarity_rules = []
    for row_idx, row in df.iterrows():
        sim_field_a = clean_cell(row.get("相似度字段A", ""))
        sim_field_b = clean_cell(row.get("相似度字段B", ""))
        if not sim_field_a and not sim_field_b:
            continue
        if not sim_field_a or not sim_field_b:
            raise ValueError(f"映射表第 {row_idx + 2} 行相似度字段A/B需成对填写")

        similarity_rules.append({
            "field_a": sim_field_a,
            "field_b": sim_field_b,
            "b_suffix_policy": b_suffix_policy,
            "order": row_idx,
        })

    if len(similarity_rules) > 1:
        raise ValueError("相似度字段A/B只能填写一组")

    # 阈值（默认20；多行配置时取第一处非空值）
    threshold = 20
    if "相似度阈值" in df.columns:
        for raw in df["相似度阈值"]:
            v = clean_cell(raw)
            if not v:
                continue
            try:
                threshold = int(float(v))
                break
            except ValueError:
                pass

    # 构建匹配键
    match_keys = {}
    for _, row in df.iterrows():
        src = clean_cell(row["原始数据"])
        if not src:
            continue
        key_name = clean_cell(row["匹配键"])
        if not key_name:
            continue
        try:
            priority_raw = clean_cell(row["优先级"])
            priority = int(float(priority_raw)) if priority_raw else 999
        except (ValueError, TypeError):
            priority = 999
        omc_col = clean_cell(row["OMC数据列"])
        if not omc_col:
            omc_col = src

        if key_name not in match_keys:
            match_keys[key_name] = {"cols_a": [], "cols_b": [], "priority": priority}
        match_keys[key_name]["cols_a"].append(src)
        match_keys[key_name]["cols_b"].append(omc_col)

    if not match_keys:
        raise ValueError("映射表中未定义任何有效的匹配键")

    return match_keys, similarity_rules, threshold, b_suffix_policy


def combo_candidates_for_value(value, combo_lookup):
    raw_value = clean_cell(value)
    combo_infos = combo_lookup.get(normalize_match_text(raw_value), [])
    if not combo_infos:
        return [{
            "value": raw_value,
            "combo": "",
            "child": "",
            "order": -1,
        }]

    return [{
        "value": info["combo"],
        "combo": info["combo"],
        "child": raw_value,
        "order": info["order"],
    } for info in combo_infos]


def normalize_key_value(values):
    key_val = "|".join("" if v is None else str(v) for v in values)
    return re.sub(r"(\|)+", "|", key_val).strip("|")


def build_a_key_value(a_row_dict, cols, variant):
    values = []
    variant_values = variant["values"]
    for col in cols:
        if col in variant_values:
            values.append(variant_values[col])
        else:
            values.append(a_row_dict.get(col, ""))
    return normalize_key_value(values)


def build_a_row_variants(a_rows, similarity_rules, match_keys, combo_lookup):
    fields = []
    seen = set()
    for rule in similarity_rules:
        field = rule["field_a"]
        if field not in seen:
            seen.add(field)
            fields.append(field)

    combo_candidate_cache = {}
    row_variants = []
    for row in a_rows:
        variants = [{"values": {}, "meta": {}}]
        for field in fields:
            raw_value = row.get(field, "")
            raw_key = normalize_match_text(raw_value)
            if raw_key not in combo_candidate_cache:
                combo_candidate_cache[raw_key] = combo_candidates_for_value(raw_value, combo_lookup)
            candidates = combo_candidate_cache[raw_key]
            next_variants = []
            for variant in variants:
                for candidate in candidates:
                    new_variant = {
                        "values": dict(variant["values"]),
                        "meta": dict(variant["meta"]),
                    }
                    new_variant["values"][field] = candidate["value"]
                    new_variant["meta"][field] = candidate
                    next_variants.append(new_variant)
            variants = next_variants
        for variant in variants:
            variant["key_values"] = {
                key_name: build_a_key_value(row, cfg["cols_a"], variant)
                for key_name, cfg in match_keys.items()
            }
            variant["sim_values"] = {
                field: normalize_match_text(variant["values"].get(field, row.get(field, "")))
                for field in fields
            }
        row_variants.append(variants)

    return row_variants


def build_variant_for_candidate(row, field, candidate, match_keys):
    variant = {
        "values": {field: candidate["value"]},
        "meta": {field: candidate},
    }
    variant["key_values"] = {
        key_name: build_a_key_value(row, cfg["cols_a"], variant)
        for key_name, cfg in match_keys.items()
    }
    variant["sim_values"] = {
        field: normalize_match_text(candidate["value"])
    }
    return variant


def build_same_key_combo_variants(a_rows, similarity_rules, match_keys, combo_rules):
    """Build combo variants that are complete inside the same match key value."""
    if not similarity_rules or not combo_rules:
        return [defaultdict(list) for _ in a_rows]

    field = similarity_rules[0]["field_a"]
    product_keys = [normalize_match_text(row.get(field, "")) for row in a_rows]
    key_combo_variants = [defaultdict(list) for _ in a_rows]

    for key_name, cfg in match_keys.items():
        groups = defaultdict(list)
        for row_idx, row in enumerate(a_rows):
            key_val = normalize_key_value(row.get(col, "") for col in cfg["cols_a"])
            if key_val:
                groups[key_val].append(row_idx)

        for row_indices in groups.values():
            group_product_keys = {product_keys[idx] for idx in row_indices if product_keys[idx]}
            if not group_product_keys:
                continue

            for rule in combo_rules:
                has_combo_product = rule["combo_key"] in group_product_keys
                has_all_children = rule["child_keys"].issubset(group_product_keys)
                if not has_combo_product and not has_all_children:
                    continue

                for row_idx in row_indices:
                    product_key = product_keys[row_idx]
                    if product_key == rule["combo_key"] or (has_all_children and product_key in rule["child_keys"]):
                        raw_child = clean_cell(a_rows[row_idx].get(field, ""))
                        candidate = {
                            "value": rule["combo"],
                            "combo": rule["combo"],
                            "child": raw_child,
                            "order": rule["order"],
                            "complete": True,
                        }
                        key_combo_variants[row_idx][key_name].append(
                            build_variant_for_candidate(a_rows[row_idx], field, candidate, match_keys)
                        )

    return key_combo_variants


# ===================== 读取 Excel =====================
def read_excel_merge_sheets(filepath):
    with pd.ExcelFile(filepath) as xl:
        sheets = xl.sheet_names
        all_dfs = []
        all_cols = set()
        for sn in sheets:
            df = pd.read_excel(xl, sheet_name=sn, dtype=str, na_filter=False)
            df = df.dropna(how="all")
            if not df.empty:
                all_dfs.append(df)
                all_cols.update(df.columns)
    if not all_dfs:
        raise ValueError("所有工作表均无有效数据")
    for df in all_dfs:
        for c in all_cols:
            if c not in df.columns:
                df[c] = None
    return pd.concat(all_dfs, ignore_index=True)


def read_excel_first_sheet(filepath, columns=None):
    usecols = None
    if columns is not None:
        wanted = {str(c).strip() for c in columns if str(c).strip()}
        usecols = lambda c: str(c).strip() in wanted
    df = pd.read_excel(filepath, dtype=str, sheet_name=0, na_filter=False, usecols=usecols)
    return df.dropna(how="all").reset_index(drop=True)


def read_excel_headers(filepath, all_sheets=False):
    ext = os.path.splitext(str(filepath))[1].lower()
    headers = []

    if ext in (".xlsx", ".xlsm"):
        wb = load_workbook(filepath, read_only=True, data_only=True)
        try:
            sheet_names = wb.sheetnames if all_sheets else wb.sheetnames[:1]
            for sheet_name in sheet_names:
                ws = wb[sheet_name]
                first_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), [])
                headers.extend(normalize_column_name(col) for col in first_row)
        finally:
            wb.close()
    else:
        with pd.ExcelFile(filepath) as xl:
            sheet_names = xl.sheet_names if all_sheets else xl.sheet_names[:1]
            for sheet_name in sheet_names:
                df = pd.read_excel(xl, sheet_name=sheet_name, nrows=0, dtype=str)
                headers.extend(normalize_column_name(col) for col in df.columns)

    return [col for col in headers if col]


def unique_preserve_order(values):
    seen = set()
    result = []
    for value in values:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result


# ===================== 高亮保存 =====================
def save_with_highlight(df, out_path, threshold):
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="匹配结果")
        wb = writer.book
        ws = writer.sheets["匹配结果"]

        # 找匹配分数列索引，兼容英文 similarity 和中文"匹配分数"。
        sim_col_idx = None
        for ci, col in enumerate(df.columns, start=1):
            if col in SIMILARITY_COLUMNS:
                sim_col_idx = ci
                break
        if sim_col_idx is None:
            return

        for row_idx in range(2, len(df) + 2):
            cell = ws.cell(row=row_idx, column=sim_col_idx)
            try:
                score = float(cell.value) if cell.value is not None else 0
            except (ValueError, TypeError):
                score = 0
            if score < threshold:
                for ci in range(1, len(df.columns) + 1):
                    ws.cell(row=row_idx, column=ci).fill = YELLOW_FILL


# ===================== B 表预分组 =====================
def collect_required_b_columns(match_keys, similarity_rules, output_columns, a_columns):
    columns = []
    seen = set()

    def add_column(col):
        if col and col not in seen:
            columns.append(col)
            seen.add(col)

    for cfg in match_keys.values():
        for col in cfg["cols_b"]:
            add_column(col)
    for rule in similarity_rules:
        add_column(rule["field_b"])
    for col in output_columns or []:
        if col in SIMILARITY_COLUMNS:
            continue
        if col == "匹配来源键":
            continue
        if col in SIMILARITY_DETAIL_COLUMNS:
            continue
        if col in COMBO_OUTPUT_COLUMNS:
            continue
        if col in a_columns:
            continue
        add_column(col)

    return columns


def collect_required_key_values(row_variants, match_keys, key_combo_variants=None):
    required = {key_name: set() for key_name in match_keys}
    def collect_from_variants(variants):
        for variant in variants:
            for key_name in match_keys:
                key_val = variant["key_values"].get(key_name, "")
                if key_val:
                    required[key_name].add(key_val)

    for variants in row_variants:
        collect_from_variants(variants)
    if key_combo_variants:
        for per_key_variants in key_combo_variants:
            for variants in per_key_variants.values():
                collect_from_variants(variants)
    return required


def get_b_cell(df_b, b_idx, col):
    if b_idx < 0 or col not in df_b.columns:
        return ""
    try:
        val = df_b.at[b_idx, col]
    except KeyError:
        return ""
    return val if val is not None else ""


def build_b_groups(df_b, match_keys, required_key_values=None):
    for key_name, cfg in match_keys.items():
        cols = cfg["cols_b"]
        key_series = df_b[cols[0]].map(clean_b_match_value)
        for c in cols[1:]:
            key_series = key_series + "|" + df_b[c].map(clean_b_match_value)
        key_series = key_series.str.replace(r"(\|)+", "|", regex=True).str.strip("|")
        df_b[f"__tmp_key_{key_name}"] = key_series

    b_groups = {}
    for key_name in match_keys:
        groups = defaultdict(list)
        tmp_col = f"__tmp_key_{key_name}"
        needed = required_key_values.get(key_name) if required_key_values else None
        for idx, kv in df_b[tmp_col].items():
            if not kv:
                continue
            if needed is not None and kv not in needed:
                continue
            groups[kv].append(idx)
        b_groups[key_name] = dict(groups)

    return b_groups, df_b


class BChoiceCache:
    def __init__(self, b_groups, sim_b_values):
        self.b_groups = b_groups
        self.sim_b_values = sim_b_values
        self.cache = {}

    def get(self, key_name, key_val, field_b):
        cache_key = (key_name, key_val, field_b)
        if cache_key in self.cache:
            return self.cache[cache_key]

        candidates = self.b_groups.get(key_name, {}).get(key_val)
        if not candidates:
            return None

        choice_info = {
            "candidates": candidates,
            "choices": [self.sim_b_values[field_b].at[candidate_idx] for candidate_idx in candidates],
        }
        self.cache[cache_key] = choice_info
        return choice_info

    def get_candidates(self, key_name, key_val):
        return self.b_groups.get(key_name, {}).get(key_val, [])


def build_a_output_signature_columns(df_a, output_columns):
    system_columns = (
        SIMILARITY_COLUMNS
        | {"匹配来源键"}
        | SIMILARITY_DETAIL_COLUMNS
        | set(COMBO_OUTPUT_COLUMNS)
    )
    if output_columns is None:
        return [c for c in df_a.columns if not str(c).startswith("__tmp_key_")]
    return [
        c for c in output_columns
        if c in df_a.columns and c not in system_columns and not str(c).startswith("__tmp_key_")
    ]


def build_a_output_signatures(a_rows, signature_columns):
    return [
        tuple(output_cell(row.get(col, "")) for col in signature_columns)
        for row in a_rows
    ]


def get_ranked_similarity_candidates(result_key, choice_info, a_sim_proc, match_result_cache):
    if result_key in match_result_cache:
        return match_result_cache[result_key]

    ranked = []
    for idx_in_candidates, choices in enumerate(choice_info["choices"]):
        best_score = -1
        best_output = ""
        for choice in choices:
            score = fuzz.WRatio(a_sim_proc, choice["value"])
            if score > best_score:
                best_score = score
                best_output = choice["output"]
        ranked.append((best_score, choice_info["candidates"][idx_in_candidates], best_output))
    ranked.sort(key=lambda item: item[0], reverse=True)
    match_result_cache[result_key] = ranked
    return ranked


def pick_unused_candidate(group_key, ranked_candidates, allocation_state, blocked_candidates=None):
    used = allocation_state[group_key]
    blocked_candidates = blocked_candidates or set()
    for item in ranked_candidates:
        b_idx = item[1]
        if b_idx not in used and b_idx not in blocked_candidates:
            return item
    return None


def get_best_combo_for_b_choices(choices, combo_rules, threshold):
    best = None
    for choice_order, choice in enumerate(choices):
        for rule in combo_rules:
            score = fuzz.WRatio(rule["combo_key"], choice["value"])
            item = (score, rule["order"], choice_order, rule, choice["output"], choice["value"])
            if (
                best is None
                or item[0] > best[0]
                or (
                    item[0] == best[0]
                    and (item[1], item[2]) < (best[1], best[2])
                )
            ):
                best = item
    if best is None or best[0] < threshold:
        return None
    return best


def build_combo_preassignments(
    a_rows,
    sorted_keys,
    b_choice_cache,
    similarity_rules,
    combo_lookup,
    combo_rules,
    a_output_signatures,
    threshold,
):
    if not similarity_rules or not combo_rules:
        return {}, defaultdict(set)

    rule = similarity_rules[0]
    field_a = rule["field_a"]
    field_b = rule["field_b"]
    product_keys = [normalize_match_text(row.get(field_a, "")) for row in a_rows]
    preassigned = {}
    blocked_b_by_signature = defaultdict(set)
    assigned_rows = set()

    for key_name, cfg in sorted_keys:
        groups = defaultdict(list)
        for row_idx, row in enumerate(a_rows):
            key_val = normalize_key_value(row.get(col, "") for col in cfg["cols_a"])
            if key_val:
                groups[key_val].append(row_idx)

        for key_val, row_indices in groups.items():
            choice_info = b_choice_cache.get(key_name, key_val, field_b)
            if not choice_info:
                continue

            b_combo_candidates = []
            for idx_in_candidates, b_idx in enumerate(choice_info["candidates"]):
                best = get_best_combo_for_b_choices(choice_info["choices"][idx_in_candidates], combo_rules, threshold)
                if best is None:
                    continue
                combo_score, combo_order, _, combo_rule, b_choice_output, b_choice_proc = best
                b_combo_candidates.append({
                    "b_idx": b_idx,
                    "b_choice": b_choice_proc,
                    "b_choice_output": b_choice_output,
                    "combo_rule": combo_rule,
                    "combo_score": combo_score,
                    "combo_order": combo_order,
                })

            if not b_combo_candidates:
                continue

            # First pass: B-side combo -> complete A-side child set.
            for b_combo in b_combo_candidates:
                b_idx = b_combo["b_idx"]
                combo_rule = b_combo["combo_rule"]
                while True:
                    picked_rows = []
                    for child_key in combo_rule["child_keys"]:
                        matched_row = None
                        for row_idx in row_indices:
                            if row_idx in assigned_rows:
                                continue
                            if product_keys[row_idx] != child_key:
                                continue
                            block_key = (key_name, key_val, a_output_signatures[row_idx])
                            if b_idx in blocked_b_by_signature[block_key]:
                                continue
                            matched_row = row_idx
                            break
                        if matched_row is None:
                            picked_rows = []
                            break
                        picked_rows.append(matched_row)

                    if not picked_rows:
                        break

                    for row_idx in picked_rows:
                        assigned_rows.add(row_idx)
                        block_key = (key_name, key_val, a_output_signatures[row_idx])
                        blocked_b_by_signature[block_key].add(b_idx)
                        preassigned[row_idx] = (
                            b_combo["combo_score"],
                            b_idx,
                            key_name,
                            rule,
                            combo_rule["combo"],
                            combo_rule["combo"],
                            clean_cell(a_rows[row_idx].get(field_a, "")),
                            b_combo["b_choice_output"],
                        )

            # Second pass: remaining child rows guess possible combos against remaining B candidates.
            partial_used_by_group = defaultdict(set)
            for row_idx in row_indices:
                if row_idx in assigned_rows:
                    continue
                raw_child = clean_cell(a_rows[row_idx].get(field_a, ""))
                combo_infos = combo_lookup.get(product_keys[row_idx], [])
                if not combo_infos:
                    continue

                possible_combos = []
                seen_combo = set()
                for info in combo_infos:
                    combo = info.get("combo", "")
                    if not combo or combo in seen_combo:
                        continue
                    seen_combo.add(combo)
                    possible_combos.append(info)
                if not possible_combos:
                    continue

                group_key = (
                    key_name,
                    key_val,
                    product_keys[row_idx],
                    a_output_signatures[row_idx],
                )
                complete_blocked = blocked_b_by_signature[(key_name, key_val, a_output_signatures[row_idx])]
                used_for_group = partial_used_by_group[group_key] | complete_blocked
                best = None
                for b_combo in b_combo_candidates:
                    b_idx = b_combo["b_idx"]
                    if b_idx in used_for_group:
                        continue
                    for info in possible_combos:
                        combo = info["combo"]
                        score = fuzz.WRatio(normalize_match_text(combo), b_combo["b_choice"])
                        item = (score, info.get("order", 999), b_idx, combo)
                        if (
                            best is None
                            or item[0] > best[0]
                            or (item[0] == best[0] and item[1] < best[1])
                        ):
                            best = item

                if best is None or best[0] < threshold:
                    continue

                score, _, b_idx, combo = best
                partial_used_by_group[group_key].add(b_idx)
                assigned_rows.add(row_idx)
                preassigned[row_idx] = (
                    score,
                    b_idx,
                    key_name,
                    rule,
                    combo,
                    combo,
                    raw_child,
                    next(
                        (item["b_choice_output"] for item in b_combo_candidates if item["b_idx"] == b_idx),
                        "",
                    ),
                )

    return preassigned, blocked_b_by_signature


# ===================== 单行匹配 =====================
def match_single_row(
    a_row_dict,
    row_idx,
    sorted_keys,
    b_choice_cache,
    similarity_rules,
    threshold,
    row_variants,
    key_combo_variants,
    preassigned_results,
    blocked_b_by_signature,
    match_result_cache,
    allocation_state,
    a_output_signatures,
):
    if row_idx in preassigned_results:
        return preassigned_results[row_idx]

    best_sim = -1
    best_b_idx = -1
    best_key = ""
    best_rule = None
    best_a_value = ""
    best_b_value = ""
    best_combo_product = ""
    best_combo_child = ""
    best_group_key = None
    a_output_signature = a_output_signatures[row_idx]
    has_similarity = bool(similarity_rules)

    priority_groups = []
    for key_name, cfg in sorted_keys:
        priority = cfg.get("priority", 999)
        if not priority_groups or priority_groups[-1][0] != priority:
            priority_groups.append((priority, [(key_name, cfg)]))
        else:
            priority_groups[-1][1].append((key_name, cfg))

    for _, keys_in_priority in priority_groups:
        tier_best_sim = -1
        tier_best_b_idx = -1
        tier_best_key = ""
        tier_best_rule = None
        tier_best_a_value = ""
        tier_best_b_value = ""
        tier_best_combo_product = ""
        tier_best_combo_child = ""
        tier_best_group_key = None

        for key_name, cfg in keys_in_priority:
            variants_for_key = key_combo_variants[row_idx].get(key_name) or row_variants[row_idx]
            for variant in variants_for_key:
                key_val = variant["key_values"].get(key_name, "")
                if not key_val:
                    continue

                if not has_similarity:
                    group_key = (key_name, key_val, a_output_signature)
                    ranked = [("", b_idx) for b_idx in b_choice_cache.get_candidates(key_name, key_val)]
                    picked = pick_unused_candidate(
                        group_key,
                        ranked,
                        allocation_state,
                        blocked_b_by_signature.get((key_name, key_val, a_output_signature), set()),
                    )
                    if picked is None:
                        continue
                    _, b_idx = picked
                    allocation_state[group_key].add(b_idx)
                    return "", b_idx, key_name, None, "", "", "", ""

                for rule in similarity_rules:
                    choice_info = b_choice_cache.get(key_name, key_val, rule["field_b"])
                    if not choice_info:
                        continue
                    best_field_a = rule["field_a"]
                    a_sim_output = variant["values"].get(best_field_a, a_row_dict.get(best_field_a, ""))
                    a_sim_proc = variant["sim_values"].get(best_field_a, normalize_match_text(a_sim_output))
                    combo_meta = variant["meta"].get(best_field_a, {})
                    result_key = (key_name, key_val, rule["field_b"], a_sim_proc)
                    group_key = (
                        key_name,
                        key_val,
                        a_sim_proc,
                        a_output_signature,
                        combo_meta.get("combo", ""),
                        combo_meta.get("child", ""),
                    )
                    ranked = get_ranked_similarity_candidates(result_key, choice_info, a_sim_proc, match_result_cache)
                    picked = pick_unused_candidate(
                        group_key,
                        ranked,
                        allocation_state,
                        blocked_b_by_signature.get((key_name, key_val, a_output_signature), set()),
                    )
                    if picked:
                        score, b_idx, b_value = picked
                        if score > tier_best_sim:
                            tier_best_sim = score
                            tier_best_b_idx = b_idx
                            tier_best_key = key_name
                            tier_best_rule = rule
                            tier_best_a_value = a_sim_output
                            tier_best_b_value = b_value
                            tier_best_combo_product = combo_meta.get("combo", "")
                            tier_best_combo_child = combo_meta.get("child", "")
                            tier_best_group_key = group_key

        if tier_best_b_idx >= 0 and tier_best_group_key is not None:
            if tier_best_sim > best_sim:
                best_sim = tier_best_sim
                best_b_idx = tier_best_b_idx
                best_key = tier_best_key
                best_rule = tier_best_rule
                best_a_value = tier_best_a_value
                best_b_value = tier_best_b_value
                best_combo_product = tier_best_combo_product
                best_combo_child = tier_best_combo_child
                best_group_key = tier_best_group_key
            if tier_best_sim >= threshold:
                allocation_state[tier_best_group_key].add(tier_best_b_idx)
                return (
                    tier_best_sim,
                    tier_best_b_idx,
                    tier_best_key,
                    tier_best_rule,
                    tier_best_a_value,
                    tier_best_combo_product,
                    tier_best_combo_child,
                    tier_best_b_value,
                )

    if best_b_idx >= 0 and best_group_key is not None:
        allocation_state[best_group_key].add(best_b_idx)
        return best_sim, best_b_idx, best_key, best_rule, best_a_value, best_combo_product, best_combo_child, best_b_value
    return "", -1, "", None, "", "", "", ""


# ===================== 后台匹配任务 =====================
def _process_match(task_id: str, paths: dict):
    try:
        # 1. 解析映射表
        match_keys, similarity_rules, threshold, _ = parse_mapping(paths["mapping"])
        output_columns = parse_output_config(paths["mapping"])
        combo_lookup, combo_rules, has_combo_relations = parse_combo_relations(paths["mapping"])

        # 2. 读取文件
        df_a = read_excel_merge_sheets(paths["a"])

        # 校验 A 表字段，B 表按需读取后再校验
        for rule in similarity_rules:
            if rule["field_a"] not in df_a.columns:
                raise ValueError(f"表A缺失相似度字段: {rule['field_a']}")
        for key_name, cfg in match_keys.items():
            for c in cfg["cols_a"]:
                if c not in df_a.columns:
                    raise ValueError(f"表A缺失列: {c}")

        total = len(df_a)
        with tasks_lock:
            tasks[task_id]["total"] = total

        a_rows = df_a.to_dict(orient="records")
        a_signature_columns = build_a_output_signature_columns(df_a, output_columns)
        a_output_signatures = build_a_output_signatures(a_rows, a_signature_columns)

        # 3. 预处理 A 表单行组合候选；完整组合和顺延分配在 B 表缓存完成后处理。
        row_variants = build_a_row_variants(a_rows, similarity_rules, match_keys, combo_lookup)
        key_combo_variants = [defaultdict(list) for _ in a_rows]
        required_key_values = collect_required_key_values(row_variants, match_keys, key_combo_variants)

        b_required_columns = None
        if output_columns is not None:
            b_required_columns = collect_required_b_columns(
                match_keys,
                similarity_rules,
                output_columns,
                set(df_a.columns),
            )
        df_b = read_excel_first_sheet(paths["b"], columns=b_required_columns)

        for rule in similarity_rules:
            if rule["field_b"] not in df_b.columns:
                raise ValueError(f"表B缺失相似度字段: {rule['field_b']}")
        for key_name, cfg in match_keys.items():
            for c in cfg["cols_b"]:
                if c not in df_b.columns:
                    raise ValueError(f"表B缺失列: {c}")

        # 4. 构建 B 表分组
        sim_b_values = {
            rule["field_b"]: df_b[rule["field_b"]].map(
                lambda value, policy=rule["b_suffix_policy"]: build_b_similarity_choices(value, policy)
            )
            for rule in similarity_rules
        }
        b_groups, df_b = build_b_groups(df_b, match_keys, required_key_values)
        b_choice_cache = BChoiceCache(b_groups, sim_b_values)
        match_result_cache = {}
        allocation_state = defaultdict(set)

        sorted_keys = sorted(match_keys.items(), key=lambda x: x[1]["priority"])
        preassigned_results, blocked_b_by_signature = build_combo_preassignments(
            a_rows,
            sorted_keys,
            b_choice_cache,
            similarity_rules,
            combo_lookup,
            combo_rules,
            a_output_signatures,
            threshold,
        )

        # 5. 匹配
        best_sim_list = [""] * total
        best_b_idx_list = [-1] * total
        best_key_list = [""] * total
        best_rule_list = [None] * total
        best_a_value_list = [""] * total
        best_b_value_list = [""] * total
        best_combo_product_list = [""] * total
        best_combo_child_list = [""] * total

        for idx in range(total):
            sim, b_idx, key, rule, a_value, combo_product, combo_child, b_value = match_single_row(
                a_rows[idx],
                idx,
                sorted_keys,
                b_choice_cache,
                similarity_rules,
                threshold,
                row_variants,
                key_combo_variants,
                preassigned_results,
                blocked_b_by_signature,
                match_result_cache,
                allocation_state,
                a_output_signatures,
            )
            best_sim_list[idx] = sim
            best_key_list[idx] = key  # 不管是否匹配到，来源键都记录
            best_rule_list[idx] = rule
            best_a_value_list[idx] = a_value
            best_b_value_list[idx] = b_value
            best_combo_product_list[idx] = combo_product
            best_combo_child_list[idx] = combo_child
            if b_idx >= 0:
                best_b_idx_list[idx] = b_idx

            with tasks_lock:
                tasks[task_id]["current"] = idx + 1

        # 6. 删除临时列
        for key_name in match_keys:
            df_a.drop(columns=[f"__tmp_key_{key_name}"], inplace=True, errors="ignore")
        for key_name in match_keys:
            c = f"__tmp_key_{key_name}"
            if c in df_b.columns:
                df_b.drop(columns=[c], inplace=True, errors="ignore")

        # 7. 构建输出列
        if output_columns is None:
            a_cols = [c for c in df_a.columns if not c.startswith("__tmp_key_")]
            b_cols = [c for c in df_b.columns if not c.startswith("__tmp_key_")]
            seen = set(a_cols)
            output_columns = list(a_cols)
            for c in b_cols:
                if c not in seen:
                    output_columns.append(c)
                    seen.add(c)
        else:
            output_columns = list(output_columns)

        has_similarity_col = any(c in SIMILARITY_COLUMNS for c in output_columns)
        if not has_similarity_col:
            output_columns.append("similarity")
        append_missing(output_columns, ["匹配来源键"])
        append_missing(output_columns, SIMILARITY_DETAIL_OUTPUT_COLUMNS)
        if has_combo_relations:
            append_missing(output_columns, COMBO_OUTPUT_COLUMNS)

        # 8. 填充数据
        result_data = {col: [""] * total for col in output_columns}

        for idx in range(total):
            a_row = a_rows[idx]
            b_idx = best_b_idx_list[idx]
            best_rule = best_rule_list[idx] or {}
            best_field_a = best_rule.get("field_a", "")
            best_field_b = best_rule.get("field_b", "")

            for col in output_columns:
                if col in SIMILARITY_COLUMNS:
                    result_data[col][idx] = best_sim_list[idx]
                elif col == "匹配来源键":
                    result_data[col][idx] = best_key_list[idx]
                elif col == "匹配相似度字段A":
                    result_data[col][idx] = best_field_a
                elif col == "匹配相似度字段B":
                    result_data[col][idx] = best_field_b
                elif col == "匹配相似度值A":
                    result_data[col][idx] = output_cell(best_a_value_list[idx]) if best_field_a else ""
                elif col == "匹配相似度值B":
                    result_data[col][idx] = output_cell(best_b_value_list[idx]) if best_field_b else ""
                elif col == "命中组合产品":
                    result_data[col][idx] = best_combo_product_list[idx]
                elif col == "命中子产品":
                    result_data[col][idx] = best_combo_child_list[idx]
                elif col in a_row:
                    val = a_row[col]
                    result_data[col][idx] = val if val is not None else ""
                elif col in df_b.columns:
                    val = get_b_cell(df_b, b_idx, col)
                    result_data[col][idx] = val if val is not None else ""

        result_df = pd.DataFrame(result_data)

        # 9. 保存（含高亮）
        a_base = paths.get("a_name", task_id)
        result_path = TMP_DIR / f"{a_base}_匹配结果.xlsx"
        save_with_highlight(result_df, str(result_path), threshold)

        with tasks_lock:
            tasks[task_id].update({
                "status": "completed",
                "result_path": str(result_path),
                "total": total,
                "a_name": a_base,
            })

    except Exception as e:
        with tasks_lock:
            tasks[task_id].update({"status": "error", "message": str(e)})


# ===================== API 路由 =====================

@router.post("/columns")
async def get_columns(file_a: UploadFile = File(...), file_b: UploadFile = File(...)):
    """预读表A和表B的列名，用于前端重名检测"""
    result = {}
    tmp_files = []
    try:
        for key, f in [("a", file_a), ("b", file_b)]:
            ext = os.path.splitext(f.filename)[1].lower()
            if ext not in (".xlsx", ".xls"):
                raise HTTPException(400, f"不支持的文件类型: {ext}")
            tmp_path = TMP_DIR / f"preview_{uuid.uuid4()}_{key}{ext}"
            content = await f.read()
            with open(tmp_path, "wb") as fh:
                fh.write(content)
            tmp_files.append(tmp_path)
            if key == "a":
                # 表A：读取所有工作表表头，去重保序
                result["a"] = unique_preserve_order(read_excel_headers(str(tmp_path), all_sheets=True))
            else:
                # 表B：只读第一个工作表
                result["b"] = unique_preserve_order(read_excel_headers(str(tmp_path), all_sheets=False))
    finally:
        for p in tmp_files:
            p.unlink(missing_ok=True)
    set_a = set(result.get("a", []))
    result["duplicates"] = [col for col in result.get("b", []) if col in set_a]
    return result


@router.post("/start")
async def start_match(file_a: UploadFile = File(...), file_b: UploadFile = File(...), mapping: UploadFile = File(...)):
    task_id = str(uuid.uuid4())
    paths = {}
    for key, f in [("a", file_a), ("b", file_b), ("mapping", mapping)]:
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in (".xlsx", ".xls"):
            raise HTTPException(400, f"不支持的文件类型: {ext}")
        p = TMP_DIR / f"{task_id}_{key}{ext}"
        content = await f.read()
        with open(p, "wb") as fh:
            fh.write(content)
        paths[key] = str(p)
        if key == "a":
            paths["a_name"] = os.path.splitext(f.filename)[0]

    # 表A 数据预检：扫描匹配键列是否含制表符/前后空格
    try:
        match_keys, _, _, _ = parse_mapping(paths["mapping"])
        df_preview = pd.read_excel(paths["a"], dtype=str, nrows=20, na_filter=False)
        bad_cols = []
        for key_name, cfg in match_keys.items():
            for col in cfg["cols_a"]:
                if col not in df_preview.columns:
                    continue
                for val in df_preview[col].astype(str):
                    if val != val.strip() or "\t" in val:
                        if col not in bad_cols:
                            bad_cols.append(col)
                        break
        if bad_cols:
            paths["precheck_warnings"] = bad_cols
    except Exception:
        pass  # 预检失败不阻断正常流程

    with tasks_lock:
        tasks[task_id] = {"status": "processing", "current": 0, "total": 0, "message": ""}

    thread = threading.Thread(target=_process_match, args=(task_id, paths))
    thread.start()

    return {"task_id": task_id}


@router.get("/status/{task_id}")
async def get_status(task_id: str):
    with tasks_lock:
        task = tasks.get(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")
    resp = {
        "status": task["status"],
        "current": task.get("current", 0),
        "total": task.get("total", 0),
    }
    if task["status"] == "error":
        resp["message"] = task.get("message", "未知错误")
    return resp


@router.get("/download/{task_id}")
async def download_result(task_id: str):
    with tasks_lock:
        task = tasks.get(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")
    if task["status"] != "completed":
        raise HTTPException(400, "任务尚未完成")
    result_path = task.get("result_path")
    if not result_path or not os.path.exists(result_path):
        raise HTTPException(404, "结果文件不存在")
    a_base = task.get("a_name", "匹配结果")
    return FileResponse(
        result_path,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=f"{a_base}_匹配结果.xlsx",
    )
