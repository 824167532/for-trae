"""
表格映射后端模块
"""
import os
import uuid
import threading
import zipfile
import shutil
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
import openpyxl

router = APIRouter()

TMP_DIR = Path("/tmp/data-workbench")
TMP_DIR.mkdir(parents=True, exist_ok=True)

tasks = {}
tasks_lock = threading.Lock()


def _parse_mapping(filepath: str) -> dict[str, list[dict]]:
    """解析映射表，返回 {报表类型: [{原始列, 输出列, 类型}]}"""
    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 2:
        raise ValueError("映射表至少需要表头+1行数据")

    headers = [str(h or "").strip() for h in rows[0]]
    # 第一列固定为"原始数据"，之后每两列为一组（输出列名, 类型）
    report_groups = {}
    col_groups = []
    i = 1
    while i < len(headers):
        name = headers[i]
        dtype = headers[i + 1] if i + 1 < len(headers) else ""
        col_groups.append((i, name, dtype))
        i += 2

    for row in rows[1:]:
        vals = [str(v or "").strip() if v is not None else "" for v in row]
        if not any(vals):
            continue
        src_col = vals[0] if vals else ""
        if not src_col:
            continue

        for idx, report_name, dtype in col_groups:
            out_col = vals[idx] if idx < len(vals) else ""
            if not out_col:
                continue
            report_groups.setdefault(report_name, []).append({
                "source_col": src_col,
                "output_col": out_col,
                "type": dtype or "text",
            })

    wb.close()
    return report_groups


def _read_source_data(filepath: str) -> list[dict]:
    """读取源数据文件（所有sheet合并）"""
    wb = openpyxl.load_workbook(filepath, data_only=True)
    all_rows = []
    for sn in wb.sheetnames:
        ws = wb[sn]
        rows_iter = list(ws.iter_rows(values_only=True))
        if not rows_iter:
            continue
        headers = [str(h or "").strip() or f"Col{i+1}" for i, h in enumerate(rows_iter[0])]
        for row in rows_iter[1:]:
            vals = [str(v or "") if v is not None else "" for v in row]
            if any(v.strip() for v in vals):
                all_rows.append(dict(zip(headers, vals)))
    wb.close()
    return all_rows


def _match_template(src_filename: str, template_paths: dict[str, str]) -> str | None:
    """按源文件名前缀匹配模板"""
    base = os.path.splitext(os.path.basename(src_filename))[0].lower()
    # 精确匹配
    for name in template_paths:
        if name.lower() == base:
            return name
    # 前缀匹配
    for name in template_paths:
        if base.startswith(name.lower()) or name.lower().startswith(base):
            return name
    # 子串匹配
    for name in template_paths:
        if name.lower() in base:
            return name
    # 通用模板
    for name in template_paths:
        if "通用" in name:
            return name
    # 第一个模板
    if template_paths:
        return list(template_paths.keys())[0]
    return None


def _fill_template(template_path: str, source_rows: list[dict], mappings: list[dict], output_dir: str, src_name: str) -> str:
    """填充模板并保存"""
    # 复制模板
    out_path = os.path.join(output_dir, f"{os.path.splitext(os.path.basename(src_name))[0]}_filled.xlsx")
    shutil.copy2(template_path, out_path)

    wb = openpyxl.load_workbook(out_path)
    ws = wb.active

    # 建立映射：源列 → (输出列, 类型)
    col_map = {m["source_col"]: (m["output_col"], m["type"]) for m in mappings}

    # 查找模板中的占位列（匹配输出列名）
    template_headers = {}
    for col_idx in range(1, ws.max_column + 1):
        val = ws.cell(row=1, column=col_idx).value
        if val:
            template_headers[str(val).strip()] = col_idx

    # 填充数据（从第2行开始）
    for ri, src_row in enumerate(source_rows):
        row_num = ri + 2
        for src_col, (out_col, dtype) in col_map.items():
            if out_col not in template_headers:
                continue
            col_idx = template_headers[out_col]
            val = src_row.get(src_col, "")

            if dtype == "float":
                try:
                    val = float(val) if val else 0.0
                except (ValueError, TypeError):
                    val = val
            elif dtype == "date":
                # 保持原值，让 Excel 自行处理
                pass

            ws.cell(row=row_num, column=col_idx, value=val)

    wb.save(out_path)
    wb.close()
    return out_path


@router.post("/start")
async def start_table_map(
    source_files: list[UploadFile] = File(...),
    template_files: list[UploadFile] = File(...),
    mapping_file: UploadFile = File(...),
):
    """启动表格映射任务"""
    task_id = str(uuid.uuid4())
    work_dir = TMP_DIR / task_id
    work_dir.mkdir(parents=True, exist_ok=True)

    def ensure_xlsx(f: UploadFile, label: str):
        ext = os.path.splitext(f.filename)[1].lower()
        if ext != ".xlsx":
            raise HTTPException(400, f"{label}仅支持 .xlsx 文件: {f.filename}")
        return ext

    # 保存映射表
    map_ext = ensure_xlsx(mapping_file, "映射表")
    map_path = work_dir / f"mapping{map_ext}"
    map_path.write_bytes(await mapping_file.read())

    # 保存源文件
    src_paths = {}
    for f in source_files:
        ensure_xlsx(f, "源数据")
        p = work_dir / f"src_{f.filename}"
        p.write_bytes(await f.read())
        src_paths[f.filename] = str(p)

    # 保存模板文件
    tmpl_paths = {}
    for f in template_files:
        ensure_xlsx(f, "模板")
        p = work_dir / f"tmpl_{f.filename}"
        p.write_bytes(await f.read())
        tmpl_paths[f.filename] = str(p)

    with tasks_lock:
        tasks[task_id] = {"status": "processing", "current": 0, "total": 0, "message": ""}

    thread = threading.Thread(target=_process_table_map, args=(task_id, str(map_path), src_paths, tmpl_paths, str(work_dir)))
    thread.start()

    return {"task_id": task_id}


def _process_table_map(task_id: str, map_path: str, src_paths: dict, tmpl_paths: dict, work_dir: str):
    """后台执行表格映射"""
    try:
        report_mappings = _parse_mapping(map_path)
        if not report_mappings:
            raise ValueError("映射表为空")

        output_dir = os.path.join(work_dir, "output")
        os.makedirs(output_dir, exist_ok=True)

        total = len(src_paths)
        with tasks_lock:
            tasks[task_id]["total"] = total

        result_files = []
        warnings = []

        for idx, (src_name, src_path) in enumerate(src_paths.items()):
            # 读取源数据
            source_rows = _read_source_data(src_path)
            if not source_rows:
                warnings.append({"file": src_name, "fields": {"info": "源文件为空"}})
                continue

            # 匹配模板：使用用户上传的原始模板文件名，而不是临时文件名。
            template_lookup = {os.path.splitext(name)[0]: path for name, path in tmpl_paths.items()}
            tmpl_name = _match_template(src_name, template_lookup)
            if not tmpl_name:
                warnings.append({"file": src_name, "fields": {"info": "未找到匹配模板"}})
                continue

            # 找到模板路径
            tmpl_path = template_lookup.get(tmpl_name) or list(tmpl_paths.values())[0]

            # 确定该源文件对应的映射（按报表类型匹配）
            # 默认使用第一个映射组
            mappings = list(report_mappings.values())[0]
            for report_name, maps in report_mappings.items():
                if report_name.lower() in src_name.lower() or report_name.lower() in tmpl_name.lower():
                    mappings = maps
                    break

            # 填充模板
            out_path = _fill_template(tmpl_path, source_rows, mappings, output_dir, src_name)
            result_files.append(os.path.basename(out_path))

            with tasks_lock:
                tasks[task_id]["current"] = idx + 1

        if not result_files:
            raise ValueError("没有生成任何输出文件")

        # 打包 ZIP
        zip_path = os.path.join(work_dir, "result.zip")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in result_files:
                zf.write(os.path.join(output_dir, f), f)

        with tasks_lock:
            tasks[task_id].update({
                "status": "completed",
                "result_files": result_files,
                "warnings": warnings,
                "output_dir": output_dir,
                "zip_path": zip_path,
                "total": total,
            })

    except Exception as e:
        with tasks_lock:
            tasks[task_id].update({"status": "error", "message": str(e)})


@router.get("/status/{task_id}")
async def get_status(task_id: str):
    """获取表格映射任务状态"""
    with tasks_lock:
        task = tasks.get(task_id)
    if not task:
        raise HTTPException(404, "任务不存在")

    resp = {
        "status": task["status"],
        "current": task.get("current", 0),
        "total": task.get("total", 0),
    }
    if task["status"] == "completed":
        resp["result_files"] = task.get("result_files", [])
        resp["warnings"] = task.get("warnings", [])
    elif task["status"] == "error":
        resp["message"] = task.get("message", "未知错误")
    return resp


@router.get("/download-single/{task_id}/{filename}")
async def download_single(task_id: str, filename: str):
    """下载单个结果文件"""
    with tasks_lock:
        task = tasks.get(task_id)
    if not task or task["status"] != "completed":
        raise HTTPException(404, "任务不存在或未完成")

    filepath = os.path.join(task["output_dir"], filename)
    if not os.path.exists(filepath):
        raise HTTPException(404, "文件不存在")

    return FileResponse(
        filepath,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        filename=filename,
    )


@router.get("/download-zip/{task_id}")
async def download_zip(task_id: str):
    """下载 ZIP 打包结果"""
    with tasks_lock:
        task = tasks.get(task_id)
    if not task or task["status"] != "completed":
        raise HTTPException(404, "任务不存在或未完成")

    zip_path = task.get("zip_path")
    if not zip_path or not os.path.exists(zip_path):
        raise HTTPException(404, "ZIP 文件不存在")

    return FileResponse(
        zip_path,
        media_type="application/zip",
        filename="表格映射结果.zip",
    )
