"""
数据工作台 - 一键启动脚本
双击运行即可，无需手动启动前端和后端
"""
import os
import sys
import subprocess
import webbrowser
import time
import threading

# 切换到项目根目录
os.chdir(os.path.dirname(os.path.abspath(__file__)))

def print_banner():
    print("=" * 50)
    print("  数据工作台 v77 普通版")
    print("  Vue 3 + FastAPI 前后端分离")
    print("=" * 50)
    print()

def check_deps():
    """检查 Python 依赖"""
    missing = []
    for mod in ["fastapi", "uvicorn", "openpyxl", "python_multipart", "chardet"]:
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)

    if missing:
        print("[*] 正在安装 Python 依赖（首次需要联网）...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", *missing],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        print("[OK] 依赖安装完成")

def open_browser():
    """延迟打开浏览器"""
    time.sleep(2)
    try:
        webbrowser.open("http://localhost:8800")
    except Exception:
        pass

def main():
    print_banner()
    check_deps()

    # 延迟打开浏览器
    threading.Thread(target=open_browser, daemon=True).start()

    print()
    print("[OK] 服务启动: http://localhost:8800")
    print("[*] 按 Ctrl+C 停止服务")
    print()

    # 启动后端（同时提供前端静态文件）
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
    import uvicorn

    uvicorn.run("backend.main:app", host="0.0.0.0", port=8800, reload=False, timeout_keep_alive=300)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n服务已停止")
    except Exception as e:
        print(f"\n[错误] 启动失败: {e}")
        print("请确认已安装 Python 3.8+，并尝试运行: pip install fastapi uvicorn openpyxl python-multipart chardet")
        input("\n按 Enter 退出...")
