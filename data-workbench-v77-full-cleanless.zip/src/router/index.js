import { createRouter, createWebHashHistory } from 'vue-router'
import MergePanel from '../views/MergePanel.vue'
import PackPanel from '../views/PackPanel.vue'
import MatchPanel from '../views/MatchPanel.vue'
import TableMapPanel from '../views/TableMapPanel.vue'

const routes = [
  { path: '/', redirect: '/merge' },
  { path: '/merge', name: 'merge', component: MergePanel },
  { path: '/pack', name: 'pack', component: PackPanel },
  { path: '/match', name: 'match', component: MatchPanel },
  { path: '/tablemap', name: 'tablemap', component: TableMapPanel },
]

export default createRouter({
  history: createWebHashHistory(),
  routes,
})
