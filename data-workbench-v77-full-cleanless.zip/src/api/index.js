const API_BASE = ''

async function request(path, options = {}) {
  const url = `${API_BASE}${path}`
  const timeout = options.timeout ?? 120000
  const fetchOptions = { ...options }
  if (timeout > 0) {
    fetchOptions.signal = options.signal || AbortSignal.timeout(timeout)
  }

  let res
  try {
    res = await fetch(url, fetchOptions)
  } catch (e) {
    if (e?.name === 'TimeoutError') {
      throw new Error('请求超时，请稍后重试')
    }
    if (e?.name === 'AbortError') {
      throw new Error('请求被中断，请重试')
    }
    throw new Error('网络连接失败（可能是隧道断开）')
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(err.detail || `请求失败: ${res.status}`)
  }
  return res
}

export async function checkBackend() {
  try {
    const res = await request('/api/health', { signal: AbortSignal.timeout(2000) })
    return res.ok
  } catch {
    return false
  }
}

// ---- 合并模块 ----
export async function uploadMergeFiles(files) {
  const formData = new FormData()
  files.forEach(f => formData.append('files', f))
  const res = await request('/merge/upload', { method: 'POST', body: formData, timeout: 0 })
  return res.json()
}

export async function applyMerge(config) {
  const res = await request('/merge/apply', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
  })
  return res.json()
}

export async function getMergeStatus(taskId) {
  const res = await request(`/merge/status/${taskId}`)
  return res.json()
}

export async function downloadMergeResult(taskId) {
  const res = await request(`/merge/download/${taskId}`)
  const blob = await res.blob()
  const disposition = res.headers.get('content-disposition') || ''
  const match = disposition.match(/filename="?(.+?)"?$/)
  const filename = match ? decodeURIComponent(match[1]) : 'result.xlsx'
  return { blob, filename }
}

// ---- 匹配模块 ----
export async function getMatchColumns(fileA, fileB) {
  const formData = new FormData()
  formData.append('file_a', fileA)
  formData.append('file_b', fileB)
  const res = await request('/match/columns', { method: 'POST', body: formData, timeout: 0 })
  return res.json()
}

export async function startMatch(fileA, fileB, mapping) {
  const formData = new FormData()
  formData.append('file_a', fileA)
  formData.append('file_b', fileB)
  formData.append('mapping', mapping)
  const res = await request('/match/start', { method: 'POST', body: formData, timeout: 0 })
  return res.json()
}

export async function getMatchStatus(taskId) {
  const res = await request(`/match/status/${taskId}`)
  return res.json()
}

export function getMatchDownloadUrl(taskId) {
  return `${API_BASE}/match/download/${taskId}`
}

// ---- 表格映射模块 ----
export async function startTableMap(srcFiles, tmplFiles, mapFile) {
  const formData = new FormData()
  srcFiles.forEach(f => formData.append('source_files', f))
  tmplFiles.forEach(f => formData.append('template_files', f))
  formData.append('mapping_file', mapFile)
  const res = await request('/table-map/start', { method: 'POST', body: formData })
  return res.json()
}

export async function getTableMapStatus(taskId) {
  const res = await request(`/table-map/status/${taskId}`)
  return res.json()
}

export function getTableMapDownloadUrl(taskId, filename) {
  return `${API_BASE}/table-map/download-single/${taskId}/${encodeURIComponent(filename)}`
}

export function getTableMapZipUrl(taskId) {
  return `${API_BASE}/table-map/download-zip/${taskId}`
}
