﻿<template>
  <div class="workbench">
    <aside class="sidebar">
      <div class="sidebar-brand">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="3" width="7" height="7" rx="1"/>
          <rect x="14" y="3" width="7" height="7" rx="1"/>
          <rect x="3" y="14" width="7" height="7" rx="1"/>
          <rect x="14" y="14" width="7" height="7" rx="1"/>
        </svg>
        <span class="brand-text">数据工作台</span>
      </div>
      <nav class="sidebar-nav" role="navigation">
        <router-link
          v-for="(tab, i) in tabs"
          :key="tab.path"
          :to="tab.path"
          class="nav-item"
          :class="{ active: $route.path === tab.path }"
          :style="{ '--i': i }"
        >
          <span class="nav-indicator"></span>
          <span class="nav-icon" v-html="tab.icon"></span>
          <span class="nav-label">{{ tab.label }}</span>
        </router-link>
      </nav>
      <div class="sidebar-footer">
        <span class="version">石板蓝 · v77</span>
      </div>
    </aside>
    <main class="main-area">
      <router-view v-slot="{ Component }">
        <transition name="page" mode="out-in">
          <keep-alive>
            <component :is="Component" />
          </keep-alive>
        </transition>
      </router-view>
    </main>
    <!-- Grain overlay -->
    <div class="grain-overlay"></div>
  </div>
</template>

<script setup>
const tabs = [
  { path: '/merge', label: '表格合并', icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>' },
  { path: '/pack', label: '文件打包', icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8v13H3V8"/><path d="M1 3h22v5H1z"/><line x1="10" y1="12" x2="14" y2="12"/></svg>' },
  { path: '/match', label: '智能匹配', icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/><line x1="11" y1="8" x2="11" y2="14"/></svg>' },
  { path: '/tablemap', label: '表格映射', icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="3" y1="15" x2="21" y2="15"/><line x1="9" y1="3" x2="9" y2="21"/></svg>' },
]
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=Sora:wght@400;500;600&display=swap');

:root {
  --primary: #475569;
  --primary-hover: #334155;
  --accent: #3b82f6;
  --accent-hover: #2563eb;
  --accent-light: #eff6ff;
  --surface: #ffffff;
  --bg: #f8fafc;
  --border: #cbd5e1;
  --border-light: #e2e8f0;
  --text: #1e293b;
  --text-secondary: #475569;
  --text-muted: #64748b;
  --success: #059669;
  --success-light: #f0fdf4;
  --danger: #ef4444;
  --danger-light: #fef2f2;
  --warning: #f59e0b;
  --warning-light: #fffbeb;
  --radius: 12px;
  --radius-sm: 8px;
  --radius-xs: 6px;
  --shadow-sm: 0 1px 2px rgba(0,0,0,.04);
  --shadow: 0 1px 3px rgba(0,0,0,.06), 0 1px 2px rgba(0,0,0,.04);
  --shadow-md: 0 4px 6px rgba(0,0,0,.06), 0 2px 4px rgba(0,0,0,.04);
  --shadow-lg: 0 10px 15px rgba(0,0,0,.08), 0 4px 6px rgba(0,0,0,.04);
  --transition: 150ms ease;
  --sidebar-w: 220px;
  --font-heading: 'DM Sans', 'Noto Sans SC', -apple-system, sans-serif;
  --font-body: 'Sora', 'Noto Sans SC', -apple-system, sans-serif;
}

* { box-sizing: border-box; margin: 0; }

body {
  font-family: var(--font-body);
  background: var(--bg); color: var(--text); line-height: 1.6; min-height: 100vh;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

/* ===== Dot Grid Background ===== */
body::before {
  content: '';
  position: fixed; inset: 0;
  background-image: radial-gradient(circle, #cbd5e1 0.5px, transparent 0.5px);
  background-size: 20px 20px;
  pointer-events: none; z-index: 0;
  opacity: .5;
}

/* ===== Grain Overlay ===== */
.grain-overlay {
  position: fixed; inset: 0; z-index: 9999;
  pointer-events: none; opacity: .015;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.8' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-repeat: repeat; background-size: 256px 256px;
}

#app { width: 100%; position: relative; z-index: 1; }

.workbench { display: flex; min-height: 100vh; }

/* ===== Sidebar ===== */
.sidebar {
  position: fixed; top: 0; left: 0; bottom: 0;
  width: var(--sidebar-w); min-width: var(--sidebar-w);
  background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
  display: flex; flex-direction: column;
  z-index: 10; overflow-y: auto;
}

.sidebar-brand {
  display: flex; align-items: center; gap: 10px;
  padding: 24px 20px 20px; color: #fff;
}

.sidebar-brand svg { flex-shrink: 0; opacity: .9; }

.brand-text {
  font-size: 16px; font-weight: 700; letter-spacing: .02em;
  font-family: var(--font-heading);
}

.sidebar-nav {
  flex: 1; padding: 8px 12px;
  display: flex; flex-direction: column; gap: 2px;
}

.nav-item {
  position: relative;
  display: flex; align-items: center; gap: 10px;
  padding: 12px 14px; padding-left: 16px;
  border-radius: 10px;
  font-size: 14px; font-weight: 500;
  color: rgba(255,255,255,.55);
  text-decoration: none; cursor: pointer;
  transition: all .25s cubic-bezier(.4,0,.2,1);
  min-height: 44px;
  overflow: hidden;
  animation: navSlideIn .4s ease both;
  animation-delay: calc(var(--i, 0) * 60ms);
}

@keyframes navSlideIn {
  from { opacity: 0; transform: translateX(-12px); }
  to { opacity: 1; transform: translateX(0); }
}

.nav-indicator {
  position: absolute; left: 0; top: 50%;
  width: 3px; height: 0;
  background: var(--accent);
  border-radius: 0 3px 3px 0;
  transform: translateY(-50%);
  transition: height .25s cubic-bezier(.4,0,.2,1);
}

.nav-item.active .nav-indicator {
  height: 60%;
}

.nav-item:hover {
  color: #fff; background: rgba(255,255,255,.08);
  transform: translateX(4px);
}

.nav-item.active {
  color: #fff; background: rgba(59,130,246,.15);
  font-weight: 600;
  box-shadow: 0 0 20px rgba(59,130,246,.08);
}

.nav-item:focus-visible { outline: 2px solid rgba(255,255,255,.5); outline-offset: -2px; }

.nav-icon { display: flex; align-items: center; opacity: .7; flex-shrink: 0; }
.nav-item.active .nav-icon { opacity: 1; }
.nav-item:hover .nav-icon { opacity: .9; }

.sidebar-footer { padding: 16px 20px; }

.version { font-size: 12px; color: rgba(255,255,255,.3); font-family: var(--font-body); }

/* ===== Main Area ===== */
.main-area {
  flex: 1; margin-left: var(--sidebar-w);
  padding: 24px 28px 40px; min-width: 0;
}

/* ===== Page Transitions ===== */
.page-enter-active {
  animation: pageIn .35s cubic-bezier(.4,0,.2,1);
}
.page-leave-active {
  animation: pageOut .2s cubic-bezier(.4,0,1,1);
}

@keyframes pageIn {
  from { opacity: 0; transform: translateY(12px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes pageOut {
  from { opacity: 1; transform: translateY(0); }
  to { opacity: 0; transform: translateY(-8px); }
}

/* ===== Shared Heading Styles ===== */
h1, h2, h3, h4 {
  font-family: var(--font-heading);
  letter-spacing: -.01em;
}

/* ===== Responsive ===== */
@media (max-width: 768px) {
  .sidebar { width: 64px; min-width: 64px; }
  .brand-text, .nav-label, .version { display: none; }
  .sidebar-brand { padding: 20px 16px 16px; justify-content: center; }
  .nav-item { justify-content: center; padding: 12px; border-radius: 8px; }
  .nav-indicator { display: none; }
  .sidebar-nav { padding: 8px 6px; }
  .main-area { margin-left: 64px; padding: 16px 12px 24px; }
}

@media (max-width: 480px) {
  .main-area { padding: 12px 8px 20px; }
}
</style>
