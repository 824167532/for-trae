<template>
  <div
    class="upload-zone"
    :class="{ 'drag-over': isDragOver, 'has-file': hasFile }"
    @dragenter.prevent="onDragEnter"
    @dragover.prevent="onDragOver"
    @dragleave.prevent="onDragLeave"
    @drop.prevent="onDrop"
    @click="$emit('trigger')"
    role="button"
    tabindex="0"
    @keydown.enter="$emit('trigger')"
    @keydown.space.prevent="$emit('trigger')"
    :aria-label="title"
  >
    <div class="upload-glow"></div>
    <div class="upload-content">
      <div class="upload-icon-wrap">
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" class="upload-icon">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
          <polyline points="17 8 12 3 7 8"/>
          <line x1="12" y1="3" x2="12" y2="15"/>
        </svg>
      </div>
      <span class="upload-title">{{ title }}</span>
      <span class="upload-hint">{{ hint }}</span>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

defineProps({ title: String, hint: String, hasFile: Boolean })
const emit = defineEmits(['files-drop', 'trigger'])

const isDragOver = ref(false)
let dragCounter = 0

function onDragEnter() {
  dragCounter++
  isDragOver.value = true
}
function onDragOver() { isDragOver.value = true }
function onDragLeave() {
  dragCounter--
  if (dragCounter <= 0) { dragCounter = 0; isDragOver.value = false }
}
function onDrop(e) {
  isDragOver.value = false; dragCounter = 0
  if (e.dataTransfer?.files?.length) emit('files-drop', e.dataTransfer.files)
}
</script>

<style scoped>
.upload-zone {
  position: relative;
  border: 2px dashed var(--border, #cbd5e1);
  border-radius: var(--radius, 12px);
  padding: 32px 20px;
  text-align: center;
  cursor: pointer;
  transition: all .3s cubic-bezier(.4,0,.2,1);
  background: var(--surface, #fff);
  overflow: hidden;
  min-height: 120px;
  display: flex; align-items: center; justify-content: center;
}

.upload-zone:hover {
  border-color: var(--accent, #3b82f6);
  background: var(--accent-light, #eff6ff);
  transform: translateY(-2px);
  box-shadow: var(--shadow-md, 0 4px 6px rgba(0,0,0,.06));
}

.upload-zone.drag-over {
  border-color: var(--accent, #3b82f6);
  background: var(--accent-light, #eff6ff);
  transform: scale(1.02);
  box-shadow: 0 0 0 4px rgba(59,130,246,.1), var(--shadow-lg, 0 10px 15px rgba(0,0,0,.08));
}

.upload-zone:focus-visible {
  outline: 2px solid var(--accent, #3b82f6);
  outline-offset: 2px;
}

/* Glow border animation on hover */
.upload-glow {
  position: absolute; inset: -2px;
  border-radius: inherit;
  opacity: 0;
  transition: opacity .3s;
  pointer-events: none;
}

.upload-zone:hover .upload-glow,
.upload-zone.drag-over .upload-glow {
  opacity: 1;
}

.upload-content {
  position: relative; z-index: 1;
  display: flex; flex-direction: column; align-items: center; gap: 6px;
}

.upload-icon-wrap {
  color: var(--text-muted, #64748b);
  transition: all .3s cubic-bezier(.4,0,.2,1);
}

.upload-zone:hover .upload-icon-wrap,
.upload-zone.drag-over .upload-icon-wrap {
  color: var(--accent, #3b82f6);
  transform: translateY(-4px);
}

.upload-zone.drag-over .upload-icon-wrap {
  animation: bounce .5s ease infinite;
}

@keyframes bounce {
  0%, 100% { transform: translateY(-4px); }
  50% { transform: translateY(-10px); }
}

.upload-title {
  font-size: 15px; font-weight: 600;
  color: var(--text, #1e293b);
  font-family: var(--font-heading, 'DM Sans', sans-serif);
}

.upload-hint {
  font-size: 12px; color: var(--text-muted, #64748b);
}

/* 已上传文件状态 */
.upload-zone.has-file {
  border-color: #059669;
  background: #ecfdf5;
}

.upload-zone.has-file .upload-icon-wrap {
  color: #059669;
}

.upload-zone.has-file .upload-title::after {
  content: ' ✓';
  color: #059669;
}
</style>