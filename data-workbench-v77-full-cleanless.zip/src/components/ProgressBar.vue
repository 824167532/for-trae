<template>
  <div class="progress-wrap" v-if="visible">
    <div class="progress-label">{{ label }}</div>
    <div class="progress-track">
      <div class="progress-fill" :style="{ width: pct + '%' }">
        <div class="progress-shimmer"></div>
      </div>
    </div>
    <div class="progress-text">{{ current }} / {{ total }}</div>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({ visible: Boolean, current: Number, total: Number, label: String })
const pct = computed(() => props.total > 0 ? Math.min(100, Math.round(props.current / props.total * 100)) : 0)
</script>

<style scoped>
.progress-wrap {
  display: flex; align-items: center; gap: 10px;
  margin: 12px 0; padding: 10px 16px;
  background: var(--surface, #fff);
  border-radius: var(--radius-sm, 8px);
  border: 1px solid var(--border, #cbd5e1);
  animation: slideDown .3s ease;
}

@keyframes slideDown {
  from { opacity: 0; transform: translateY(-8px); }
  to { opacity: 1; transform: translateY(0); }
}

.progress-label {
  font-size: 13px; font-weight: 600; white-space: nowrap;
  color: var(--text, #1e293b);
  font-family: var(--font-heading, 'DM Sans', sans-serif);
}

.progress-track {
  flex: 1; height: 8px;
  background: var(--bg, #f8fafc);
  border-radius: 99px; overflow: hidden;
  position: relative;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--accent, #3b82f6), #6366f1);
  border-radius: 99px;
  transition: width .4s cubic-bezier(.4,0,.2,1);
  position: relative;
  overflow: hidden;
}

.progress-shimmer {
  position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.3), transparent);
  animation: shimmer 1.5s ease infinite;
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}

.progress-text {
  font-size: 12px; color: var(--text-muted, #64748b);
  white-space: nowrap; font-variant-numeric: tabular-nums;
}
</style>