<template>
  <div class="preview-wrapper">
    <div v-if="!columns.length" class="empty-preview">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" opacity=".35">
        <rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="3" x2="9" y2="21"/>
      </svg>
      <p>暂无数据</p>
    </div>
    <table v-else>
      <thead>
        <tr>
          <th
            v-for="col in columns"
            :key="col"
            :draggable="draggable"
            @dragstart="onColDragStart($event, col)"
            @dragover.prevent="onColDragOver($event, col)"
            @drop="onColDrop($event, col)"
            @dragend="onColDragEnd"
            :class="{ 'drag-over': dragCol === col }"
          >
            <div class="th-content">
              <span @dblclick="editable ? $emit('edit-col', col) : null" :style="editable ? 'cursor:pointer' : ''">{{ col }}</span>
              <div v-if="editable" class="th-actions">
                <button v-if="isTouch" class="col-action-btn" @click.stop="$emit('swap-cols-left', col)" title="左移" aria-label="左移列">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <button v-if="isTouch" class="col-action-btn" @click.stop="$emit('swap-cols-right', col)" title="右移" aria-label="右移列">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
                <button class="col-action-btn" @click.stop="$emit('delete-col', col)" title="删除列" aria-label="删除列">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
            </div>
          </th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(row, ri) in displayRows" :key="ri" :style="{ '--i': ri }">
          <td v-for="col in columns" :key="col">{{ row[col] ?? '' }}</td>
        </tr>
      </tbody>
    </table>
    <div v-if="totalRows > maxRows" class="preview-note">仅展示前 {{ maxRows }} 行（共 {{ totalRows }} 行）</div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  columns: { type: Array, default: () => [] },
  rows: { type: Array, default: () => [] },
  totalRows: { type: Number, default: 0 },
  maxRows: { type: Number, default: 100 },
  draggable: { type: Boolean, default: false },
  editable: { type: Boolean, default: false },
})

const emit = defineEmits(['swap-cols', 'swap-cols-left', 'swap-cols-right', 'delete-col', 'edit-col'])
const isTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0
const displayRows = computed(() => props.rows.slice(0, props.maxRows))
const dragCol = ref(null)

function onColDragStart(e, col) { dragCol.value = col; e.target.style.opacity = '0.5' }
function onColDragOver(e, col) { if (col !== dragCol.value) e.target.closest('th').classList.add('drag-over') }
function onColDrop(e, col) {
  e.target.closest('th').classList.remove('drag-over')
  if (dragCol.value && col !== dragCol.value) emit('swap-cols', dragCol.value, col)
  dragCol.value = null
}
function onColDragEnd(e) {
  e.target.style.opacity = '1'
  document.querySelectorAll('.drag-over').forEach(el => el.classList.remove('drag-over'))
}
</script>

<style scoped>
.preview-wrapper {
  border-radius: var(--radius-sm, 8px);
  background: var(--surface, #fff);
  border: 1px solid var(--border, #cbd5e1);
  overflow: auto; max-height: 360px; margin-top: 14px;
  box-shadow: var(--shadow-sm, 0 1px 2px rgba(0,0,0,.04));
}

.empty-preview { padding: 40px; text-align: center; color: var(--text-muted, #64748b); }
.empty-preview p { margin-top: 8px; font-size: 14px; }

table { width: 100%; border-collapse: collapse; font-size: 13px; white-space: nowrap; }

th {
  background: linear-gradient(180deg, #1e293b 0%, #334155 100%);
  color: #fff; font-weight: 600; padding: 10px 14px;
  position: sticky; top: 0; border-right: 1px solid #475569;
  cursor: grab; user-select: none;
  font-family: var(--font-heading, 'DM Sans', sans-serif);
  font-size: 12px; text-transform: uppercase; letter-spacing: .03em;
}

th.drag-over { background: #475569; outline: 2px dashed var(--accent, #3b82f6); outline-offset: -2px; }

.th-content { display: flex; align-items: center; justify-content: space-between; gap: 6px; }
.th-actions { display: flex; align-items: center; gap: 2px; }

.col-action-btn {
  background: none; border: none; color: #94a3b8; cursor: pointer;
  padding: 4px; min-width: 24px; min-height: 24px;
  display: flex; align-items: center; justify-content: center;
  border-radius: 4px; transition: all .15s;
}

.col-action-btn:hover { color: #fff; background: rgba(255,255,255,.12); }

td {
  padding: 8px 14px; border-bottom: 1px solid var(--border-light, #e2e8f0);
  color: var(--text, #1e293b); font-variant-numeric: tabular-nums;
}

tr {
  animation: rowFadeIn .25s ease both;
  animation-delay: calc(var(--i, 0) * 15ms);
}

@keyframes rowFadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

tr:hover td { background: var(--accent-light, #eff6ff); }

.preview-note {
  padding: 8px; text-align: center;
  color: var(--text-muted, #64748b); font-size: 13px;
}
</style>