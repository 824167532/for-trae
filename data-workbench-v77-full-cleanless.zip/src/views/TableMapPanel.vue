<template>
  <div class="tablemap-panel">
    <div class="panel-header">
      <h3>表格映射</h3>
      <span class="badge">模板填充</span>
    </div>
    <div class="desc">
      <strong>功能说明：</strong>根据映射表将源数据填入模板，生成多个报表。<br>
      • <strong>源数据文件</strong>：原始 Excel（多个 sheet 自动合并，.xlsx）<br>
      • <strong>模板文件</strong>：预设格式的模板（含公式/样式，.xlsx）<br>
      • <strong>映射表</strong>：定义列名对应关系（必含"原始数据"列，其他列为输出类型，可配合"类型"列）<br>
      <strong>启动方式：</strong>双击 <code>启动工具.bat</code>
    </div>

    <div class="info-card">
      <details open>
        <summary style="font-weight:600; cursor:pointer;">映射表结构示例</summary>
        <div class="info-content">
          <p><strong>列说明：</strong>第一列固定为"原始数据"，之后每两列为一组："报表名称"和"报表名称类型"（后者可选：text/date/float）。</p>
          <div class="example-table-wrap">
            <table class="example-table">
              <thead>
                <tr>
                  <th>原始数据</th>
                  <th>财务报表</th>
                  <th>财务报表类型</th>
                  <th>税务报表</th>
                  <th>税务报表类型</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>产品名称</td><td>产品</td><td>text</td><td>产品名</td><td>text</td></tr>
                <tr><td>金额</td><td>金额</td><td>float</td><td>金额</td><td>float</td></tr>
                <tr><td>日期</td><td>日期</td><td>date</td><td></td><td></td></tr>
              </tbody>
            </table>
          </div>
          <p><strong>模板匹配原则：</strong>优先按源文件名前缀匹配模板，其次使用含"通用"字样模板。</p>
        </div>
      </details>
    </div>

    <div class="upload-grid">
      <div>
        <FileUploader title="源数据" :hint="`已选 ${srcFiles.length} 个文件`" @files-drop="onSrcDrop" @trigger="triggerInput('src')" />
        <input :ref="el => inputs.src = el" type="file" class="file-input" accept=".xlsx" multiple @change="onSrcChange" />
      </div>
      <div>
        <FileUploader title="模板" :hint="`已选 ${tmplFiles.length} 个文件`" @files-drop="onTmplDrop" @trigger="triggerInput('tmpl')" />
        <input :ref="el => inputs.tmpl = el" type="file" class="file-input" accept=".xlsx" multiple @change="onTmplChange" />
      </div>
      <div>
        <FileUploader title="映射表" :hint="mapFile ? mapFile.name : '单个 .xlsx'" @files-drop="(f) => mapFile = f[0]" @trigger="triggerInput('map')" />
        <input :ref="el => inputs.map = el" type="file" class="file-input" accept=".xlsx" @change="(e) => mapFile = e.target.files[0]" />
      </div>
    </div>

    <div class="file-bar">
      <span class="file-stats">{{ statusText }}</span>
      <button class="btn" @click="clearAll">清空</button>
    </div>

    <div class="action-row">
      <button class="btn btn-primary" @click="startMapping" :disabled="!allReady || !backendOnline">
        {{ processing ? '映射中...' : '开始映射' }}
      </button>
      <span :class="['backend-status', backendOnline ? 'online' : 'offline']">
        {{ backendOnline ? '后端已连接' : '后端未连接' }}
      </span>
    </div>

    <ProgressBar :visible="processing" :current="progress.current" :total="progress.total" label="映射进度" />

    <div v-if="resultReady" class="result-area">
      <button v-if="resultFiles.length === 1" class="btn btn-primary" @click="downloadSingle">下载 XLSX</button>
      <button v-if="resultFiles.length > 1" class="btn btn-primary" @click="downloadZip">下载 ZIP</button>
      <div class="result-files">
        <div v-for="f in resultFiles" :key="f">{{ f }}</div>
      </div>
      <div v-if="warnings.length" class="warnings">
        <strong>警告：</strong>
        <div v-for="w in warnings" :key="w">{{ w }}</div>
      </div>
    </div>

    <div v-if="errorMsg" class="error-msg">{{ errorMsg }}</div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import FileUploader from '../components/FileUploader.vue'
import ProgressBar from '../components/ProgressBar.vue'
import { checkBackend, startTableMap, getTableMapStatus, getTableMapDownloadUrl, getTableMapZipUrl } from '../api'

const srcFiles = ref([])
const tmplFiles = ref([])
const mapFile = ref(null)
const inputs = ref({ src: null, tmpl: null, map: null })
const backendOnline = ref(false)
const processing = ref(false)
const progress = ref({ current: 0, total: 0 })
const taskId = ref(null)
const resultReady = ref(false)
const resultFiles = ref([])
const warnings = ref([])
const errorMsg = ref('')

const allReady = computed(() => srcFiles.value.length && tmplFiles.value.length && mapFile.value)
const statusText = computed(() => {
  if (!allReady.value) return '请选择所有文件'
  return `源${srcFiles.value.length}个 | 模板${tmplFiles.value.length}个 | 映射表:${mapFile.value.name}`
})

onMounted(async () => {
  backendOnline.value = await checkBackend()
  setInterval(async () => { backendOnline.value = await checkBackend() }, 10000)
})

function onSrcDrop(files) { srcFiles.value = Array.from(files) }
function onSrcChange(e) { srcFiles.value = Array.from(e.target.files); e.target.value = '' }
function onTmplDrop(files) { tmplFiles.value = Array.from(files) }
function onTmplChange(e) { tmplFiles.value = Array.from(e.target.files); e.target.value = '' }
function triggerInput(key) { inputs.value[key]?.click() }

function clearAll() {
  srcFiles.value = []
  tmplFiles.value = []
  mapFile.value = null
  resultReady.value = false
  errorMsg.value = ''
}

async function startMapping() {
  if (!allReady.value || !backendOnline.value) return
  processing.value = true
  errorMsg.value = ''
  resultReady.value = false
  progress.value = { current: 0, total: 0 }
  try {
    const { task_id } = await startTableMap(srcFiles.value, tmplFiles.value, mapFile.value)
    taskId.value = task_id
    await pollStatus()
  } catch (e) {
    errorMsg.value = e.message
  } finally {
    processing.value = false
  }
}

async function pollStatus() {
  for (let i = 0; i < 300; i++) {
    const data = await getTableMapStatus(taskId.value)
    if (data.status === 'completed') {
      progress.value = { current: data.total, total: data.total }
      resultFiles.value = data.result_files || []
      warnings.value = (data.warnings || []).map(w => `${w.file}: ${Object.keys(w.fields).join(',')}`)
      resultReady.value = true
      return
    } else if (data.status === 'error') {
      throw new Error(data.message || '映射出错')
    } else {
      progress.value = { current: data.current || 0, total: data.total || 1 }
    }
    await new Promise(r => setTimeout(r, 1000))
  }
  throw new Error('映射超时')
}

function downloadSingle() {
  if (taskId.value && resultFiles.value.length) {
    window.open(getTableMapDownloadUrl(taskId.value, resultFiles.value[0]), '_blank')
  }
}
function downloadZip() {
  if (taskId.value) window.open(getTableMapZipUrl(taskId.value), '_blank')
}
</script>

<style scoped>
.panel-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.panel-header h3{font-weight:700;font-size:18px;color:#1e293b}
.badge{background:#f1f5f9;color:#475569;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
.desc{color:#64748b;margin-bottom:18px;font-size:14px;border-left:3px solid #cbd5e1;padding-left:14px;line-height:1.7}
.info-card{background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;margin-bottom:18px}
.info-content{font-size:13px;color:#475569;line-height:1.7;margin-top:8px}
.info-content p{margin:6px 0}
.example-table-wrap{overflow-x:auto;margin:10px 0;border:1px solid #cbd5e1;border-radius:8px;background:#fff}
.example-table{border-collapse:collapse;font-size:12px;min-width:100%;white-space:nowrap}
.example-table th{background:#1e293b;color:#fff;text-align:left;padding:6px 10px;font-weight:500}
.example-table td{padding:6px 10px;border-bottom:1px solid #f1f5f9;color:#475569}
.upload-grid{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px}
.upload-grid>div{flex:1;min-width:200px}
.file-input{display:none}
.file-bar{display:flex;align-items:center;justify-content:space-between;margin:10px 0}
.file-stats{background:#f1f5f9;padding:4px 14px;border-radius:20px;font-size:13px;color:#64748b}
.action-row{display:flex;gap:12px;align-items:center;margin:12px 0}
.backend-status{font-size:13px}
.backend-status.online{color:#059669}
.backend-status.offline{color:#d97706}
.result-area{margin-top:16px}
.result-files{font-size:13px;margin-top:8px;color:#64748b}
.warnings{color:#dc2626;margin-top:8px;font-size:13px}
.btn{background:#fff;border:1px solid #cbd5e1;padding:8px 16px;border-radius:8px;font-weight:500;font-size:13px;color:#475569;cursor:pointer;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;transition:all .15s;min-height:36px}
.btn:hover{background:#f8fafc;border-color:#64748b;transform:translateY(-1px);box-shadow:0 2px 8px rgba(0,0,0,.06)}
.btn:focus-visible{outline:2px solid #475569;outline-offset:2px}
.btn-primary{background:#475569;border-color:#475569;color:#fff}
.btn-primary:hover{background:#334155;border-color:#334155;transform:translateY(-1px);box-shadow:0 4px 12px rgba(59,130,246,.25)}
.btn:disabled{opacity:.5;cursor:not-allowed}
.status-msg{color:#475569;font-size:13px}
.error-msg{color:#dc2626;margin-top:12px;font-size:13px}
</style>
