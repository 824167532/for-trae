<template>
  <div class="merge-panel">
    <div class="panel-header">
      <h3>表格合并</h3>
      <span class="badge">{{ doMerge ? '合并模式' : '独立模式' }}</span>
    </div>
    <div class="desc">
      上传 Excel/CSV 文件，选择合并输出或按子表独立输出
    </div>

    <!-- 上传区域 -->
    <FileUploader
      
      title="点击或拖拽上传"
      hint=".xlsx .csv"
      @files-drop="onFilesDrop"
      @trigger="openFilePicker"
    />
    <input
      ref="fileInput"
      type="file"
      class="file-input"
      accept=".xlsx,.csv"
      multiple
      @change="onFileChange"
    />

    <!-- 文件列表 -->
    <div class="file-bar">
      <span class="file-stats">{{ files.length }} 个表</span>
      <button class="btn" @click="clearAll">清空</button>
    </div>
    <div class="file-items" v-if="files.length">
      <div
        v-for="(f, i) in sortedFiles"
        :key="f.id"
        class="file-card"
        :draggable="!isTouch"
        @dragstart="onFileDragStart(i, $event)"
        @dragover.prevent="onFileDragOver(i)"
        @drop="onFileDrop(i)"
        @dragend="onFileDragEnd"
        :class="{ 'drag-over': dragFileIdx === i }"
      >
        <div class="file-header">
          <span class="file-info">{{ f.name }}</span>
          <div class="file-actions">
            <button class="toggle-all-btn" @click.stop="toggleAllSheets(f)">
              {{ allSheetsSelected(f) ? '取消全选' : '全选' }}
            </button>
            <button v-if="isTouch && i > 0" class="move-btn" @click="moveFile(i, i-1)"></button>
            <button v-if="isTouch && i < files.length-1" class="move-btn" @click="moveFile(i, i+1)"></button>
            <button class="remove-btn" @click="removeFile(f.id)"></button>
          </div>
        </div>
        <div class="sheet-list">
          <div
            v-for="sheet in f.sheets"
            :key="sheet.name"
            class="sheet-item"
            :class="{
              disabled: !sheet.selected,
              active: !doMerge && selectedSheet?.fileId === f.id && selectedSheet?.sheetName === sheet.name
            }"
            @click="doMerge ? null : selectSheet(f.id, sheet.name)"
          >
            <input type="checkbox" v-model="sheet.selected" @click.stop />
            <span class="sheet-name">{{ sheet.name }}</span>
            <span class="sheet-meta">{{ sheet.headers.length }}列 {{ sheet.rowCount }}行</span>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="file-items empty">暂无表格</div>

    <!-- 处理模式 -->
    <div v-if="files.length" class="process-mode-bar">
      <div class="mode-group">
        <label><input type="checkbox" v-model="doMerge"> 合并为单表</label>
        <label v-if="doMerge" class="sub-option"><input type="checkbox" v-model="addSourceCol"> 添加来源列</label>
      </div>
    </div>

    <!-- 配置选项 -->
    <div v-if="doMerge" class="options-row">
      <label><input type="radio" v-model="colOrder" value="appearance"> 首次出现</label>
      <label><input type="radio" v-model="colOrder" value="alphabetical"> 字母序</label>
      <label><input type="radio" v-model="colOrder" value="custom"> 自定义</label>
      <button class="btn" @click="resetColumnOrder">重置列序</button>
    </div>

    <!-- 操作按钮 -->
    <div class="action-row">
      <button class="btn btn-primary" @click="apply" :disabled="!files.length || status === 'processing'">
        {{ status === 'processing' ? '处理中...' : '应用' }}
      </button>
      <span class="status-msg">{{ statusMsg }}</span>
    </div>

    <!-- 进度条 -->
    <ProgressBar
      :visible="status === 'processing'"
      :current="progress.current"
      :total="progress.total"
      label="处理进度"
    />

    <!-- 预览 -->
    <div class="stats-row" v-if="displayColumns.length">
      <span>{{ displayColumns.length }} 列 · {{ displayRows.length }} 行</span>
      <span v-if="totalSourceRows > 100 && status !== 'preview'" class="truncate-hint">预览前100行，共{{ totalSourceRows }}行</span>
      <span :class="['process-badge', { processed: status === 'preview' }]">
        {{ status === 'preview' ? '已处理' : '原始' }}
      </span>
    </div>
    <DataTable
      :columns="displayColumns"
      :rows="displayRows"
      :totalRows="displayRows.length"
      :draggable="doMerge"
      :editable="doMerge"
      @swap-cols="onSwapCols"
      @swap-cols-left="onSwapColLeft"
      @swap-cols-right="onSwapColRight"
      @delete-col="onDeleteCol"
      @edit-col="onEditCol"
    />

    <!-- 下载 -->
    <div class="action-bar" v-if="status === 'preview'">
      <div></div>
      <div class="action-bar-right">
        <input type="text" v-model="resultFilename" class="filename-input" placeholder="文件名" />
        <button class="btn btn-primary" @click="download">下载 XLSX</button>
      </div>
    </div>

    <!-- 解析中提示 -->
    <div v-if="parsing" class="parsing-msg">正在解析文件，请稍候...</div>

    <!-- 错误信息 -->
    <div v-if="errorMsg" class="error-msg">{{ errorMsg }}</div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useMergeStore } from '../stores/merge'
import { uploadMergeFiles } from '../api'
import FileUploader from '../components/FileUploader.vue'
import DataTable from '../components/DataTable.vue'
import ProgressBar from '../components/ProgressBar.vue'

const store = useMergeStore()
const fileInput = ref(null)
const isTouch = ref(false)

// 从 store 解构响应式状态
const files = computed(() => store.files)
const selectedSheet = computed(() => store.selectedSheet)
const sortedFiles = computed(() => store.sortedFiles)
const allColumns = computed(() => store.allColumns)
const doMerge = computed({ get: () => store.doMerge, set: v => store.doMerge = v })
const addSourceCol = computed({ get: () => store.addSourceCol, set: v => store.addSourceCol = v })
const sourceColName = computed({ get: () => store.sourceColName, set: v => store.sourceColName = v })
const colOrder = computed({ get: () => store.colOrder, set: v => store.colOrder = v })
const customColumns = computed({ get: () => store.customColumns, set: v => store.customColumns = v })
const status = computed(() => store.status)
const progress = computed(() => store.progress)
const previewData = computed(() => store.previewData)
const errorMsg = computed(() => store.errorMsg)
const resultFilename = computed({ get: () => store.resultFilename, set: v => store.resultFilename = v })

const displayColumns = computed(() => {
  // 合并模式：显示全局列集合；独立模式：仅显示当前预览子表列
  const base = doMerge.value
    ? Array.from(new Set([...(allColumns.value || []), ...(addSourceCol.value ? [sourceColName.value] : [])]))
    : (previewData.value.columns || [])

  let ordered
  if (colOrder.value === 'custom' && customColumns.value?.length) {
    const filtered = customColumns.value.filter(c => base.includes(c))
    ordered = filtered.length ? filtered : base
  } else if (colOrder.value === 'alphabetical') {
    ordered = [...base].sort((a, b) => String(a).localeCompare(String(b), 'zh-Hans-CN'))
  } else {
    ordered = base
  }

  // 来源列始终置顶
  if (addSourceCol.value && ordered.includes(sourceColName.value)) {
    ordered = ordered.filter(c => c !== sourceColName.value)
    ordered.unshift(sourceColName.value)
  }
  return ordered
})

const displayRows = computed(() => {
  // 处理完成后，展示后端返回的结果预览
  if (status.value === 'preview') {
    return previewData.value.rows || []
  }

  // 上传后预览：合并模式显示“各子表预览行”的合并结果
  if (doMerge.value) {
    const rows = []
    for (const f of (sortedFiles.value || [])) {
      for (const s of (f.sheets || [])) {
        if (!s.selected) continue
        for (const vals of (s.previewRows || [])) {
          const row = {}
          ;(s.headers || []).forEach((h, i) => { row[h] = vals[i] || '' })
          if (addSourceCol.value) {
            row[sourceColName.value] = f.name
          }
          rows.push(row)
          if (rows.length >= 100) return rows
        }
      }
    }
    return rows
  }

  // 独立模式：显示当前子表预览
  return previewData.value.rows || []
})

// 拖拽状态
const dragFileIdx = ref(null)
const parsing = ref(false)

const statusMsg = computed(() => {
  switch (status.value) {
    case 'idle': return ''
    case 'uploading': return '上传中...'
    case 'processing': return '处理中...'
    case 'preview': return '处理完成'
    case 'error': return errorMsg.value
    default: return ''
  }
})

// 源数据总行数（用于截断提示）
const totalSourceRows = computed(() => {
  let count = 0
  for (const f of (sortedFiles.value || [])) {
    for (const s of (f.sheets || [])) {
      if (s.selected) count += (s.rowCount || 0)
    }
  }
  return count
})

onMounted(() => {
  isTouch.value = 'ontouchstart' in window || navigator.maxTouchPoints > 0
})

function openFilePicker() {
  fileInput.value?.click()
}

function onFilesDrop(files) {
  handleFiles(files)
}

function onFileChange(e) {
  handleFiles(Array.from(e.target.files))
  e.target.value = ''
}

function selectSheet(fileId, sheetName) {
  store.selectSheet(fileId, sheetName)
}

async function handleFiles(fileList) {
  parsing.value = true
  try {
    // 直接上传到后端解析，避免浏览器端卡死
    const result = await uploadMergeFiles(Array.from(fileList))
    const uploadedFiles = result.files || []
    store.addFilesFromBackend(uploadedFiles)
  } catch (e) {
    console.warn('上传失败:', e)
    const msg = e.message || '网络错误'
    if (msg.includes('隧道断开') || msg.includes('网络连接失败')) {
      store.setError('文件上传失败：网络连接中断（可能是隧道失效）。请刷新页面并更换最新手机链接后重试。')
    } else {
      store.setError('文件上传失败：' + msg)
    }
  } finally {
    parsing.value = false
  }
}

// 文件拖拽排序
function onFileDragStart(idx, e) {
  dragFileIdx.value = idx
  e.target.style.opacity = '0.5'
}
function onFileDragOver(idx) {
  if (idx !== dragFileIdx.value) dragFileIdx.value = idx
}
function onFileDrop(idx) {
  if (dragFileIdx.value !== null && idx !== dragFileIdx.value) {
    store.moveFile(dragFileIdx.value, idx)
  }
  dragFileIdx.value = null
}
function onFileDragEnd(e) {
  e.target.style.opacity = '1'
  dragFileIdx.value = null
}

// 列操作
function getWorkingColumns() {
  const base = doMerge.value
    ? [...Array.from(new Set([...(allColumns.value || []), ...(addSourceCol.value ? [sourceColName.value] : [])]))]
    : [...(previewData.value.columns || [])]
  if (customColumns.value && customColumns.value.length) {
    const filtered = customColumns.value.filter(c => base.includes(c))
    if (filtered.length) return filtered
  }
  return base
}

function onSwapCols(col1, col2) {
  const cols = getWorkingColumns()
  const i1 = cols.indexOf(col1)
  const i2 = cols.indexOf(col2)
  if (i1 === -1 || i2 === -1) return
  ;[cols[i1], cols[i2]] = [cols[i2], cols[i1]]
  customColumns.value = cols
  colOrder.value = 'custom'
}

function onDeleteCol(col) {
  const cols = getWorkingColumns()
  if (cols.length <= 1) return
  customColumns.value = cols.filter(c => c !== col)
  colOrder.value = 'custom'
}

function onSwapColLeft(col) {
  const cols = getWorkingColumns()
  const i = cols.indexOf(col)
  if (i <= 0) return
  ;[cols[i - 1], cols[i]] = [cols[i], cols[i - 1]]
  customColumns.value = cols
  colOrder.value = 'custom'
}

function onSwapColRight(col) {
  const cols = getWorkingColumns()
  const i = cols.indexOf(col)
  if (i === -1 || i >= cols.length - 1) return
  ;[cols[i + 1], cols[i]] = [cols[i], cols[i + 1]]
  customColumns.value = cols
  colOrder.value = 'custom'
}

function onEditCol(col) {
  const newName = prompt('新列名', col)
  if (!newName || newName === col) return
  const trimmed = newName.trim()
  const cols = getWorkingColumns()
  if (cols.includes(trimmed)) { alert('列名已存在'); return }
  customColumns.value = cols.map(c => c === col ? trimmed : c)
  colOrder.value = 'custom'
}

function resetColumnOrder() {
  customColumns.value = [...allColumns.value]
  colOrder.value = 'custom'
}

function clearAll() { store.clearAll() }
function apply() { store.apply(displayColumns.value) }
function download() { store.download() }
function removeFile(id) { store.removeFile(id) }
function moveFile(from, to) { store.moveFile(from, to) }

function allSheetsSelected(file) {
  return file.sheets.every(s => s.selected)
}

function toggleAllSheets(file) {
  const allSelected = allSheetsSelected(file)
  file.sheets.forEach(s => { s.selected = !allSelected })
}

</script>

<style scoped>
.panel-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.panel-header h3{font-weight:700;font-size:18px;color:#1e293b}
.badge{background:#f1f5f9;color:#475569;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
.desc{color:#64748b;margin-bottom:18px;font-size:14px;border-left:3px solid #cbd5e1;padding-left:14px}
.file-input{display:none}
.file-bar{display:flex;align-items:center;justify-content:space-between;margin:10px 0 8px;flex-wrap:wrap;gap:8px}
.file-stats{background:#f1f5f9;padding:4px 14px;border-radius:20px;font-size:13px;color:#64748b}
.file-items{background:#f8fafc;border-radius:12px;padding:8px 14px;margin:12px 0 16px;max-height:240px;overflow-y:auto;border:1px solid #cbd5e1}
.file-items.empty{display:flex;align-items:center;justify-content:center;gap:8px;color:#64748b;padding:24px;font-size:14px}
.file-card{padding:10px;margin:4px 0;border-bottom:1px solid #cbd5e1;background:#fff;border-radius:8px;cursor:grab;transition:all .15s}
.file-card:last-child{border-bottom:none}.file-card:hover{box-shadow:0 2px 8px rgba(0,0,0,.04);transform:translateX(2px)}
.file-card.drag-over{background:#f1f5f9;outline:2px dashed #475569;outline-offset:-2px}
.file-header{display:flex;align-items:center;gap:8px}
.file-info{font-weight:500;color:#1e293b;font-size:14px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.file-actions{display:flex;gap:2px;align-items:center;flex-shrink:0}
.remove-btn,.move-btn{background:none;border:none;color:#64748b;cursor:pointer;padding:4px;min-width:28px;min-height:28px;display:flex;align-items:center;justify-content:center;border-radius:6px;transition:all .15s}
.remove-btn:hover{color:#dc2626;background:#fef2f2}
.move-btn:hover{color:#475569;background:#f1f5f9}
.sheet-list{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;padding-left:24px}
.sheet-item{display:flex;align-items:center;gap:4px;font-size:12px;background:#f1f5f9;padding:4px 10px;border-radius:12px;cursor:pointer;transition:all .2s}.sheet-item:hover:not(.disabled){background:#eff6ff;transform:translateY(-1px)}
.sheet-item.disabled{opacity:.5}
.sheet-item input{accent-color:#475569}
.sheet-name{font-weight:500}
.sheet-meta{color:#64748b}
.options-row{display:flex;align-items:center;flex-wrap:wrap;gap:10px 16px;margin:12px 0;background:#f8fafc;padding:10px 16px;border-radius:12px;border:1px solid #cbd5e1}
.opt-label{display:flex;align-items:center;gap:4px;font-size:13px;cursor:pointer;color:#475569;white-space:nowrap}
.opt-label input[type=checkbox],.opt-label input[type=radio]{accent-color:#475569}
.source-col-bar{display:flex;align-items:center;gap:8px;margin:8px 0;padding:8px 16px;background:#f8fafc;border-radius:12px;font-size:13px;border:1px solid #cbd5e1}
.source-col-input{padding:5px 12px;border-radius:8px;border:1px solid #cbd5e1;width:120px;font-size:13px}
.source-col-input:focus{outline:none;border-color:#475569;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
.source-col-hint{color:#64748b;font-size:12px}
.action-row{display:flex;align-items:center;gap:12px;margin:12px 0}
.btn{background:#fff;border:1px solid #cbd5e1;padding:8px 16px;border-radius:8px;font-weight:500;font-size:13px;color:#475569;cursor:pointer;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;transition:all .15s;min-height:36px}
.btn:hover{background:#f8fafc;border-color:#64748b;transform:translateY(-1px);box-shadow:0 2px 8px rgba(0,0,0,.06)}
.btn:focus-visible{outline:2px solid #475569;outline-offset:2px}
.btn-sm{padding:5px 12px;font-size:12px}
.btn-primary{background:#475569;border-color:#475569;color:#fff}
.btn-primary:hover{background:#334155;border-color:#334155;transform:translateY(-1px);box-shadow:0 4px 12px rgba(59,130,246,.25)}
.btn:disabled{opacity:.5;cursor:not-allowed}
.status-msg{color:#475569;font-size:13px}
.stats-row{display:flex;justify-content:space-between;margin:5px 0;font-size:13px;color:#64748b}
.process-badge{padding:2px 10px;border-radius:20px;background:#f1f5f9;font-size:12px}
.process-badge.processed{background:#eff6ff;color:#166534}
.action-bar{display:flex;justify-content:space-between;align-items:center;margin-top:16px;flex-wrap:wrap;gap:8px}
.action-bar-right{display:flex;align-items:center;gap:10px}
.filename-input{padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;font-size:13px;flex:1;min-width:160px}
.filename-input:focus{outline:none;border-color:#475569;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
.status-card{padding:10px 16px;border-radius:8px;margin-top:12px;font-size:13px;display:flex;align-items:center;gap:8px}
.status-card.info{background:#f1f5f9;color:#475569;border:1px solid #bbf7d0}
.status-card.error{background:#fef2f2;color:#dc2626;border:1px solid #fecaca}
.process-mode-bar{display:flex;align-items:center;gap:24px;margin:8px 0;padding:10px 16px;font-size:13px;background:#f8fafc;border-radius:12px;border:1px solid #cbd5e1}
.mode-group{display:flex;align-items:center;gap:14px}
.sub-option{font-size:12px;color:#64748b;padding-left:4px}
.toggle-all-btn{background:none;border:1px solid #cbd5e1;border-radius:8px;font-size:11px;padding:2px 8px;color:#64748b;cursor:pointer;white-space:nowrap;transition:all .15s}
.toggle-all-btn:hover{background:#f1f5f9}
.truncate-hint{color:#d97706;font-size:12px;background:#fffbeb;padding:2px 8px;border-radius:10px}
.parsing-msg{color:#475569;margin-top:12px;font-size:13px;text-align:center;padding:8px;background:#f1f5f9;border-radius:8px}
.error-msg{color:#dc2626;margin-top:12px;font-size:13px}
.sheet-item.active{background:#eff6ff;border:2px solid #475569;box-shadow:0 0 0 1px #475569;font-weight:600}
</style>
