<template>
  <div class="pack-panel">
    <div class="panel-header">
      <h3>文件打包</h3>
      <span class="badge">ZIP</span>
    </div>
    <div class="desc">多文件打包下载</div>

    <FileUploader
      
      title="点击或拖拽上传"
      @files-drop="onDrop"
      @trigger="openPicker"
    />
    <input ref="fileInput" type="file" class="file-input" multiple @change="onChange" />

    <div class="file-bar">
      <span class="file-stats">{{ packFiles.length }} 个文件</span>
      <button class="btn" @click="packFiles = []">清空</button>
    </div>
    <div class="file-items" v-if="packFiles.length">
      <div v-for="(f, i) in packFiles" :key="i" class="file-row">
        <span class="file-info">{{ f.name }}</span>
        <button class="remove-btn" @click="packFiles.splice(i, 1)" title="移除" aria-label="移除文件"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
    </div>
    <div v-else class="file-items empty">暂无文件</div>

    <div class="pack-actions">
      <input type="text" v-model="zipName" class="filename-input" placeholder="名称" />
      <button class="btn btn-primary" @click="downloadZip" :disabled="!packFiles.length">下载 ZIP</button>
    </div>
    <span class="status-msg">{{ packStatus }}</span>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import FileUploader from '../components/FileUploader.vue'

const packFiles = ref([])
const zipName = ref('打包文件')
const packStatus = ref('')
const fileInput = ref(null)

function openPicker() { fileInput.value?.click() }
function onDrop(files) { packFiles.value.push(...files) }
function onChange(e) { packFiles.value.push(...Array.from(e.target.files)); e.target.value = '' }

async function downloadZip() {
  if (!packFiles.value.length) return
  const JSZip = window.JSZip
  if (!JSZip) { packStatus.value = 'JSZip 未加载'; return }
  const zip = new JSZip()
  packFiles.value.forEach(f => zip.file(f.name, f))
  const blob = await zip.generateAsync({ type: 'blob' })
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = (zipName.value.trim() || '打包文件') + '.zip'
  a.click()
  packStatus.value = '打包完成'
}
</script>

<style scoped>
.panel-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.panel-header h3{font-weight:700;font-size:18px;color:#1e293b}
.badge{background:#f1f5f9;color:#475569;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
.desc{color:#64748b;margin-bottom:18px;font-size:14px;border-left:3px solid #cbd5e1;padding-left:14px}
.file-input{display:none}
.file-bar{display:flex;align-items:center;justify-content:space-between;margin:10px 0 8px}
.file-stats{background:#f1f5f9;padding:4px 14px;border-radius:20px;font-size:13px;color:#64748b}
.file-items{background:#f8fafc;border-radius:12px;padding:8px 14px;margin:12px 0 16px;max-height:240px;overflow-y:auto;border:1px solid #cbd5e1}
.file-items.empty{display:flex;align-items:center;justify-content:center;color:#64748b;padding:24px;font-size:14px}
.file-row{display:flex;align-items:center;justify-content:space-between;padding:10px;margin:4px 0;border-bottom:1px solid #cbd5e1;background:#fff;border-radius:8px}
.file-row:last-child{border-bottom:none}
.file-info{font-weight:500;color:#1e293b;font-size:14px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.remove-btn{background:none;border:none;color:#64748b;cursor:pointer;padding:4px;min-width:28px;min-height:28px;display:flex;align-items:center;justify-content:center;border-radius:6px;transition:all .15s}
.remove-btn:hover{color:#dc2626;background:#fef2f2}
.pack-actions{display:flex;gap:10px;margin-top:16px}
.filename-input{padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;font-size:13px;flex:1}
.filename-input:focus{outline:none;border-color:#475569;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
.btn{background:#fff;border:1px solid #cbd5e1;padding:8px 16px;border-radius:8px;font-weight:500;font-size:13px;color:#475569;cursor:pointer;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;transition:all .15s;min-height:36px}
.btn:hover{background:#f8fafc;border-color:#64748b;transform:translateY(-1px);box-shadow:0 2px 8px rgba(0,0,0,.06)}
.btn:focus-visible{outline:2px solid #475569;outline-offset:2px}
.btn-primary{background:#475569;border-color:#475569;color:#fff}
.btn-primary:hover{background:#334155;border-color:#334155;transform:translateY(-1px);box-shadow:0 4px 12px rgba(59,130,246,.25)}
.btn:disabled{opacity:.5;cursor:not-allowed}
.status-msg{color:#475569;font-size:13px}
</style>