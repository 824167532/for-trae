<template>
  <div class="match-panel">
    <div class="panel-header">
      <h3>智能匹配 · v3.0</h3>
      <span class="badge">后端服务</span>
    </div>
    <div class="desc">
      <strong>上传要求：</strong><br>
      • <strong>表A</strong>：待匹配的原始数据（支持多工作表合并，.xlsx/.xls）<br>
      • <strong>表B</strong>：参照目标数据（只读取第一个工作表，.xlsx/.xls）<br>
      • <strong>映射表</strong>：匹配规则配置（.xlsx/.xls），第一个工作表写匹配规则，可选"输出配置"和"组合关系"子表<br>
      <strong>启动方式：</strong>双击 <code>启动工具.bat</code>
    </div>

    <!-- 映射表说明 -->
    <div class="info-card">
      <details open>
        <summary style="font-weight:600; cursor:pointer;">映射表结构说明</summary>
        <div class="info-content">
          <a class="btn example-download" href="/examples/智能匹配映射表示例.xlsx" download>下载示例映射表</a>
          <p><strong>工作表1：匹配规则</strong>，放在映射表第一个工作表即可，表名可以叫 <code>匹配规则</code>，也可以保持 Excel 默认的 <code>Sheet1</code>。</p>
          <p><strong>必填列：</strong> <code>原始数据</code>、<code>匹配键</code>、<code>优先级</code>、<code>OMC数据列</code>。<strong>可选列：</strong> <code>相似度字段A</code>、<code>相似度字段B</code>、<code>相似度阈值</code>、<code>B后缀处理</code>。</p>
          <p><strong>相似度字段规则：</strong><code>相似度字段A/B</code> 最多只能填写一组；不填写时只按匹配键输出，匹配分数和相似度详情为空。<code>相似度阈值</code> 可填在任意一行，系统取第一处非空值。<code>B后缀处理</code> 可填 <code>无后缀</code>、<code>有后缀</code>，不填默认 <code>无后缀</code>；只影响 <code>相似度字段B</code>，不影响 <code>key1/key2</code> 匹配键。</p>
          <p><strong>匹配键写法：</strong>建议用 <code>key1</code>、<code>key2</code>、<code>key3</code>、<code>key4</code> 命名；数字越小越优先。相同 <code>匹配键</code> 会把多列拼在一起作为一组条件；高优先级匹配分数达到阈值后会立即采用，不再让低优先级匹配键覆盖。</p>
          <p><strong>组合识别范围：</strong>如果 <code>key1</code> 由月份+号码组成，系统只会在同一个月份+号码里识别和凑对子产品；不同月份、不同号码、不同公司的产品不会互相组成组合，也不会共享 B 表候选。</p>

          <div class="example-table-wrap">
            <table class="example-table">
              <thead>
                <tr>
                  <th>原始数据</th>
                  <th>匹配键</th>
                  <th>优先级</th>
                  <th>OMC数据列</th>
                  <th>相似度字段A</th>
                  <th>相似度字段B</th>
                  <th>相似度阈值</th>
                  <th>B后缀处理</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>发展日期</td><td>key1</td><td>1</td><td>完成日期</td><td>订购活动名称</td><td>OMC产品</td><td>40</td><td>无后缀</td></tr>
                <tr><td>服务号码</td><td>key1</td><td>1</td><td>加密手机号</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>分公司</td><td>key1</td><td>1</td><td>城市</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>发展月</td><td>key2</td><td>2</td><td>发展月</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>服务号码</td><td>key2</td><td>2</td><td>加密手机号</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>分公司</td><td>key2</td><td>2</td><td>城市</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>发展日期</td><td>key3</td><td>3</td><td>完成日期</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>服务号码</td><td>key3</td><td>3</td><td>加密手机号</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>发展月</td><td>key4</td><td>4</td><td>发展月</td><td></td><td></td><td></td><td></td></tr>
                <tr><td>服务号码</td><td>key4</td><td>4</td><td>加密手机号</td><td></td><td></td><td></td><td></td></tr>
              </tbody>
            </table>
          </div>

          <p><strong>工作表2：输出配置（可选）</strong>，表名必须叫 <code>输出配置</code>，只需一列 <code>输出列名</code>，按顺序列出想要输出的列。<code>匹配分数</code> 和 <code>similarity</code> 都会输出匹配分数。<code>匹配相似度字段A</code>、<code>匹配相似度字段B</code>、<code>匹配相似度值A</code>、<code>匹配相似度值B</code> 属于默认输出列，不写也会输出；如果写了，就按这里的位置输出，不会重复。</p>
          <div class="example-table-wrap" style="max-width:420px;">
            <table class="example-table">
              <thead><tr><th>输出列名</th></tr></thead>
              <tbody>
                <tr><td>账期</td></tr>
                <tr><td>分公司</td></tr>
                <tr><td>手机号码</td></tr>
                <tr><td>服务号码</td></tr>
                <tr><td>城市</td></tr>
                <tr><td>发展月</td></tr>
                <tr><td>用户id</td></tr>
                <tr><td>OMCID</td></tr>
                <tr><td>OMC产品</td></tr>
                <tr><td>订购活动名称</td></tr>
                <tr><td>结算金额</td></tr>
                <tr><td>T账期</td></tr>
                <tr><td>佣金政策</td></tr>
                <tr><td>计提描述</td></tr>
                <tr><td>结算情况</td></tr>
              </tbody>
            </table>
          </div>

          <p><strong>工作表3：组合关系（可选）</strong>，用于处理 B 表是组合产品、A 表可能只有部分子产品的情况。固定列为 <code>组合产品</code>、<code>子产品1</code>、<code>子产品2</code>，需要更多子产品时继续加 <code>子产品3</code>、<code>子产品4</code>。新版逻辑会先看同 key 下 B 表实际出现了哪些组合产品，再按组合关系回到 A 表里找子产品凑组；凑齐完整组合时优先占用对应 A 行和 B 行，剩余重复子产品再顺延匹配剩下的 B 组合候选。</p>
          <div class="example-table-wrap">
            <table class="example-table">
              <thead>
                <tr>
                  <th>组合产品</th>
                  <th>子产品1</th>
                  <th>子产品2</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>20元流量特惠包+5g新通话</td><td>新通话-明星来电白银组合包B</td><td>20元流量特惠包（150元充值满减券）</td></tr>
                <tr><td>特惠流量包+宠物洗护39.9元</td><td>20元流量特惠包（150元充值满减券）</td><td>宠物洗护服务包（流量版）</td></tr>
                <tr><td>20元60G流量畅享包(W)12个月</td><td>20元12G流量月包</td><td></td></tr>
                <tr><td>35元流量月包娱乐版（电渠专属）</td><td>20元12G流量月包</td><td>咪咕视频钻石会员包月15元</td></tr>
                <tr><td>随心选会员合约（电渠专属）</td><td>10元畅享流量包</td><td>视频随心选E版（无流量版）</td></tr>
                <tr><td>咪咕短剧情感优享包12个月合约（电渠）</td><td>咪咕视频钻石会员包月15元</td><td>咪咕短剧情感精品会员</td></tr>
                <tr><td>30元40G流量月包</td><td>5G特惠包（2023版）20元档</td><td>20元12G流量月包</td></tr>
                <tr><td>上海移动20元随意换叠加包+18元饿了么轻享权益包</td><td>20元随意换叠加包</td><td>18元饿了么轻享权益包</td></tr>
                <tr><td>上海移动20元随意换叠加包+18元淘宝闪购轻享权益包</td><td>20元随意换叠加包</td><td>18元淘宝闪购轻享权益包</td></tr>
              </tbody>
            </table>
          </div>

          <p><strong>匹配策略：</strong>先按匹配键优先级从小到大找候选，每个优先级内部取本档最高分；本档分数达到阈值就停止，不再看低优先级。命中组合关系时，B 表先反向识别组合，A 表在同 key 内完整凑组，完整组合优先；未凑齐的重复子产品会拿所有可能组合去和剩余 B 候选比较，取最像的一条。普通匹配也会顺延：同 key、同 A 相似度值、同 A 输出配置的重复行，不会反复抢同一条 B，而是按分数从高到低、B 表从上到下继续取下一条。B 表产品名带 <code>@</code> 时，<code>无后缀</code> 会去掉 <code>@</code> 后内容参与相似度，<code>有后缀</code> 会使用完整 B 值参与相似度；<code>匹配相似度值B</code> 会显示实际使用的值。</p>
          <p><strong>阈值默认 20</strong>，可在映射表任意一行填写，系统取第一处非空值（如 80）。未填写相似度字段时只按匹配键输出，匹配分数为空。</p>
          <p><strong>固定输出列：</strong>如果输出配置未包含 <code>匹配分数</code> 或 <code>similarity</code>，系统会自动追加 <code>similarity</code>；<code>匹配来源键</code> 和 4 个相似度详情列也会自动追加。存在有效组合关系时，<code>命中组合产品</code> 和 <code>命中子产品</code> 也会自动输出。</p>
        </div>
      </details>
    </div>

    <!-- 上传区域 -->
    <div class="upload-grid">
      <div>
        <FileUploader title="表A" :hint="fileHints.a" :has-file="!!files.a" @files-drop="(f) => setFile('a', f[0])" @trigger="triggerInput('a')" />
        <div v-if="files.a" class="file-tag">✅ {{ files.a.name }}</div>
        <input :ref="el => inputs.a = el" type="file" class="file-input" accept=".xlsx,.xls" @change="(e) => setFile('a', e.target.files[0])" />
      </div>
      <div>
        <FileUploader title="表B" :hint="fileHints.b" :has-file="!!files.b" @files-drop="(f) => setFile('b', f[0])" @trigger="triggerInput('b')" />
        <div v-if="files.b" class="file-tag">✅ {{ files.b.name }}</div>
        <input :ref="el => inputs.b = el" type="file" class="file-input" accept=".xlsx,.xls" @change="(e) => setFile('b', e.target.files[0])" />
      </div>
      <div>
        <FileUploader title="映射表" :hint="fileHints.c" :has-file="!!files.c" @files-drop="(f) => setFile('c', f[0])" @trigger="triggerInput('c')" />
        <div v-if="files.c" class="file-tag">✅ {{ files.c.name }}</div>
        <input :ref="el => inputs.c = el" type="file" class="file-input" accept=".xlsx,.xls" @change="(e) => setFile('c', e.target.files[0])" />
      </div>
    </div>

    <div class="file-bar">
      <span class="file-stats">{{ statusText }}</span>
      <button class="btn" @click="clearAll">清空</button>
    </div>

    <!-- 重名列提示 -->
    <div v-if="columnsChecking" class="dup-hint checking">正在检测列名重复，文件较大时可能需要较久...</div>
    <div v-else-if="dupColumns.length > 0" class="dup-hint warn">
      <strong>注意：表A 和 表B 存在 {{ dupColumns.length }} 个同名列：</strong>
      <span class="dup-tags">
        <span v-for="col in dupColumns" :key="col" class="dup-tag">{{ col }}</span>
      </span>
      <span class="dup-note">同名列优先保留表A的数据，表B的该列不会覆盖。</span>
    </div>
    <div v-else-if="columnsError" class="dup-hint warn">
      <strong>列名检测失败：</strong>{{ columnsError }}
      <span class="dup-note">这不代表没有重名列，请检查文件是否能正常读取，或稍后重新选择文件。</span>
    </div>
    <div v-else-if="files.a && files.b && !columnsChecking" class="dup-hint ok">列名检测完成，无重名列。</div>

    <div class="action-row">
      <button class="btn btn-primary" @click="startMatching" :disabled="!allReady || !backendOnline">
        {{ processing ? '匹配中...' : '开始匹配' }}
      </button>
      <span :class="['backend-status', backendOnline ? 'online' : 'offline']">
        {{ backendOnline ? '后端已连接' : '后端未连接' }}
      </span>
    </div>

    <ProgressBar :visible="processing" :current="progress.current" :total="progress.total" label="匹配进度" />

    <div v-if="resultReady" class="result-area">
      <button class="btn btn-primary" @click="downloadResult">下载匹配结果</button>
      <span class="status-msg">{{ resultMsg }}</span>
    </div>

    <div v-if="errorMsg" class="error-msg">{{ errorMsg }}</div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import FileUploader from '../components/FileUploader.vue'
import ProgressBar from '../components/ProgressBar.vue'
import { checkBackend, startMatch as apiStartMatch, getMatchStatus, getMatchDownloadUrl, getMatchColumns } from '../api'

const files = ref({ a: null, b: null, c: null })
const inputs = ref({ a: null, b: null, c: null })
const fileHints = ref({ a: '点击或拖拽 .xlsx', b: '点击或拖拽 .xlsx', c: '点击或拖拽 .xlsx' })
const backendOnline = ref(false)
const processing = ref(false)
const progress = ref({ current: 0, total: 0 })
const taskId = ref(null)
const resultReady = ref(false)
const resultMsg = ref('')
const errorMsg = ref('')

const allReady = computed(() => files.value.a && files.value.b && files.value.c)

const dupColumns = ref([])
const columnsChecking = ref(false)
const columnsError = ref('')

// 表A/B选好后自动检测重名列
watch([() => files.value.a, () => files.value.b], async ([fileA, fileB]) => {
  dupColumns.value = []
  columnsError.value = ''
  if (!fileA || !fileB) return
  columnsChecking.value = true
  try {
    const data = await getMatchColumns(fileA, fileB)
    if (Array.isArray(data.duplicates)) {
      dupColumns.value = data.duplicates
    } else {
      const setA = new Set(data.a || [])
      dupColumns.value = (data.b || []).filter(col => setA.has(col))
    }
  } catch (e) {
    columnsError.value = e.message || '后端没有返回列名检测结果'
  } finally {
    columnsChecking.value = false
  }
})
const statusText = computed(() => {
  const parts = []
  if (files.value.a) parts.push(`表A(${files.value.a.name})`)
  if (files.value.b) parts.push(`表B(${files.value.b.name})`)
  if (files.value.c) parts.push(`映射表(${files.value.c.name})`)
  return parts.length === 3 ? `已选择：${parts.join('、')}` : '请选择三个文件'
})

onMounted(async () => {
  backendOnline.value = await checkBackend()
  setInterval(async () => { backendOnline.value = await checkBackend() }, 10000)
})

function setFile(key, file) {
  if (file) {
    files.value[key] = file
    fileHints.value[key] = '已选择 ✓'
    if (inputs.value[key]) inputs.value[key].value = ''
  }
}
function triggerInput(key) { inputs.value[key]?.click() }

function clearAll() {
  files.value = { a: null, b: null, c: null }
  fileHints.value = { a: '点击或拖拽 .xlsx', b: '点击或拖拽 .xlsx', c: '点击或拖拽 .xlsx' }
  resultReady.value = false
  errorMsg.value = ''
  columnsError.value = ''
  dupColumns.value = []
  taskId.value = null
}

async function startMatching() {
  if (!allReady.value || !backendOnline.value) return
  processing.value = true
  errorMsg.value = ''
  resultReady.value = false
  progress.value = { current: 0, total: 0 }
  try {
    const result = await apiStartMatch(files.value.a, files.value.b, files.value.c)
    if (result.warnings?.length) {
      errorMsg.value = `表A以下匹配键列含前后空格或制表符，请先在源文件中修正后再匹配：${result.warnings.join('、')}`
      return
    }
    if (!result.task_id) {
      throw new Error('后端未返回任务 ID')
    }
    taskId.value = result.task_id
    await pollStatus()
  } catch (e) {
    errorMsg.value = e.message
  } finally {
    processing.value = false
  }
}

async function pollStatus() {
  for (let i = 0; i < 1800; i++) {
    const data = await getMatchStatus(taskId.value)
    if (data.status === 'completed') {
      progress.value = { current: data.total, total: data.total }
      resultReady.value = true
      resultMsg.value = `匹配成功！共 ${data.total} 行`
      return
    } else if (data.status === 'error') {
      throw new Error(data.message || '匹配出错')
    } else {
      progress.value = { current: data.current || 0, total: data.total || 1 }
    }
    await new Promise(r => setTimeout(r, 1000))
  }
  throw new Error('匹配超时（超过60分钟），数据量过大请分批处理或减少匹配规则')
}

function downloadResult() {
  if (taskId.value) window.open(getMatchDownloadUrl(taskId.value), '_blank')
}
</script>

<style scoped>
.panel-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.panel-header h3{font-weight:700;font-size:18px;color:#1e293b}
.badge{background:#f1f5f9;color:#475569;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
.desc{color:#64748b;margin-bottom:18px;font-size:14px;border-left:3px solid #cbd5e1;padding-left:14px;line-height:1.7}
.info-card{background:#f8fafc;border:1px solid #cbd5e1;border-radius:12px;padding:16px;margin-bottom:18px}
.info-content{font-size:13px;color:#475569;line-height:1.7;margin-top:8px}
.info-content p{margin:6px 0}
.example-download{margin:2px 0 10px;text-decoration:none}
.example-table-wrap{overflow-x:auto;margin:10px 0;border:1px solid #cbd5e1;border-radius:8px;background:#fff}
.example-table{border-collapse:collapse;font-size:12px;min-width:100%;white-space:nowrap}
.example-table th{background:#1e293b;color:#fff;text-align:left;padding:6px 10px;font-weight:500}
.example-table td{padding:6px 10px;border-bottom:1px solid #f1f5f9;color:#475569}
.upload-grid{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:12px}
.upload-grid>div{flex:1;min-width:200px}
.file-input{display:none}
.file-bar{display:flex;align-items:center;justify-content:space-between;margin:10px 0}
.file-stats{background:#f1f5f9;padding:4px 14px;border-radius:20px;font-size:13px;color:#64748b}
.action-row{display:flex;gap:12px;align-items:center;margin:12px 0}
.backend-status{font-size:13px}
.backend-status.online{color:#059669}
.backend-status.offline{color:#d97706}
.result-area{margin-top:16px;display:flex;align-items:center;gap:12px}
.btn{background:#fff;border:1px solid #cbd5e1;padding:8px 16px;border-radius:8px;font-weight:500;font-size:13px;color:#475569;cursor:pointer;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;transition:all .15s;min-height:36px}
.btn:hover{background:#f8fafc;border-color:#64748b;transform:translateY(-1px);box-shadow:0 2px 8px rgba(0,0,0,.06)}
.btn:focus-visible{outline:2px solid #475569;outline-offset:2px}
.btn-primary{background:#475569;border-color:#475569;color:#fff}
.btn-primary:hover{background:#334155;border-color:#334155;transform:translateY(-1px);box-shadow:0 4px 12px rgba(59,130,246,.25)}
.btn:disabled{opacity:.5;cursor:not-allowed}
.status-msg{color:#475569;font-size:13px}
.error-msg{color:#dc2626;margin-top:12px;font-size:13px}
.dup-hint{margin:8px 0 10px;padding:10px 14px;border-radius:8px;font-size:13px;line-height:1.7;border:1px solid transparent}
.dup-hint.checking{background:#f8fafc;border-color:#e2e8f0;color:#64748b}
.dup-hint.warn{background:#fffbeb;border-color:#fcd34d;color:#92400e}
.dup-hint.ok{background:#f0fdf4;border-color:#bbf7d0;color:#166534}
.dup-tags{display:inline-flex;flex-wrap:wrap;gap:4px;margin:4px 6px 4px 0;vertical-align:middle}
.dup-tag{background:#fef3c7;border:1px solid #fcd34d;color:#92400e;padding:1px 8px;border-radius:12px;font-size:12px;font-weight:600}
.dup-note{color:#b45309;font-size:12px}
.file-tag{font-size:12px;color:#059669;margin-top:4px;padding:2px 8px;background:#ecfdf5;border-radius:6px;display:inline-block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
</style>
