import { defineStore } from 'pinia'
import { ref, computed, watch } from 'vue'
import { applyMerge, getMergeStatus, downloadMergeResult } from '../api'

const LS_KEY = 'datawb_merge_config'

function loadConfig() {
  try {
    const raw = localStorage.getItem(LS_KEY)
    return raw ? JSON.parse(raw) : null
  } catch { return null }
}

function saveConfig(state) {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify({
      addSourceCol: state.addSourceCol,
      sourceColName: state.sourceColName,
      colOrder: state.colOrder,
    }))
  } catch { /* quota exceeded, ignore */ }
}

function friendlyError(msg) {
  if (!msg) return ''
  const m = msg.toLowerCase()
  if (m.includes('codec can') || m.includes("can't decode") || m.includes('invalid start byte'))
    return '文件编码不支持，请将文件转为 UTF-8 或 GBK 编码后重试'
  if (m.includes('network') || m.includes('fetch') || m.includes('连接') || m.includes('隧道'))
    return '网络连接失败，请检查网络后刷新重试'
  if (m.includes('timeout') || m.includes('超时'))
    return '处理超时，文件可能过大，请拆分后重试'
  if (m.includes('not a valid') || m.includes('格式') || m.includes('corrupt'))
    return '文件格式不支持或已损坏，请检查文件后重试'
  if (m.includes('permission') || m.includes('权限'))
    return '没有访问权限，请检查文件是否被占用'
  return msg
}

export const useMergeStore = defineStore('merge', () => {
  // 文件列表
  const files = ref([])        // { id, name, sheets: [{ name, headers, rowCount }] }
  const fileOrder = ref([])    // 排序后的 id 列表

  // 配置（从 localStorage 恢复上次设置）
  const saved = loadConfig() || {}
  const doMerge = ref(true)
  const addSourceCol = ref(saved.addSourceCol !== undefined ? saved.addSourceCol : true)
  const sourceColName = ref(saved.sourceColName || '数据来源')
  const colOrder = ref(saved.colOrder || 'custom')
  const customColumns = ref([])

  // 当前预览的子表
  const selectedSheet = ref(null)  // { fileId, sheetName }

  // 状态
  const taskId = ref(null)
  const status = ref('idle')       // idle | uploading | processing | preview | done | error
  const progress = ref({ current: 0, total: 0 })
  const previewData = ref({ columns: [], rows: [] })
  const errorMsg = ref('')
  const resultFilename = ref('')

  const sortedFiles = computed(() => fileOrder.value.map(id => files.value.find(f => f.id === id)).filter(Boolean))

  const allColumns = computed(() => {
    const cols = new Set()
    sortedFiles.value.forEach(f => {
      f.sheets.forEach(s => s.headers.forEach(h => cols.add(h)))
    })
    return [...cols]
  })

  function addFilesFromBackend(uploadedFiles) {
    uploadedFiles.forEach(f => {
      const id = f.id || (Date.now() + Math.random())
      files.value.push({
        id,
        name: f.name,
        tmp_path: f.tmp_path,
        sheets: (f.sheets || []).map(s => ({
          name: s.name,
          headers: s.headers,
          rowCount: s.row_count || s.rowCount || 0,
          previewRows: s.preview_rows || [],
          selected: true,
        })),
      })
      fileOrder.value.push(id)
    })
    // 自动选中第一个文件的第一个子表
    selectFirstSheet()
  }

  function selectSheet(fileId, sheetName) {
    selectedSheet.value = { fileId, sheetName }
    const file = files.value.find(f => f.id === fileId)
    if (!file) {
      previewData.value = { columns: [], rows: [] }
      return
    }
    const sheet = file.sheets.find(s => s.name === sheetName)
    if (!sheet) {
      previewData.value = { columns: [], rows: [] }
      return
    }
    previewData.value = {
      columns: [...sheet.headers],
      rows: sheet.previewRows.map(vals => {
        const row = {}
        sheet.headers.forEach((h, i) => { row[h] = vals[i] || '' })
        return row
      }),
    }
  }

  function selectFirstSheet() {
    const first = sortedFiles.value[0]
    if (!first || !first.sheets.length) {
      previewData.value = { columns: [], rows: [] }
      return
    }
    selectSheet(first.id, first.sheets[0].name)
  }

  function updatePreviewFromFiles() {
    if (selectedSheet.value) {
      selectSheet(selectedSheet.value.fileId, selectedSheet.value.sheetName)
    } else {
      selectFirstSheet()
    }
  }

  function removeFile(id) {
    files.value = files.value.filter(f => f.id !== id)
    fileOrder.value = fileOrder.value.filter(fid => fid !== id)
  }

  function moveFile(fromIdx, toIdx) {
    const arr = fileOrder.value
    const [moved] = arr.splice(fromIdx, 1)
    arr.splice(toIdx, 0, moved)
  }

  function setError(msg) {
    errorMsg.value = friendlyError(msg)
    status.value = 'error'
  }

  function clearAll() {
    files.value = []
    fileOrder.value = []
    taskId.value = null
    status.value = 'idle'
    previewData.value = { columns: [], rows: [] }
    errorMsg.value = ''
  }

  async function apply(orderedColumns) {
    status.value = 'uploading'
    errorMsg.value = ''
    try {
      const fileList = sortedFiles.value
      if (!fileList.length) {
        throw new Error('没有文件')
      }

      // 文件已在上传时存到后端，直接发配置
      status.value = 'processing'
      // 如果传入了前端当前显示的列顺序，优先使用它（保证导出与前端一致）
      const effectiveColOrder = orderedColumns && orderedColumns.length ? 'custom' : colOrder.value
      const effectiveCustomColumns = orderedColumns && orderedColumns.length ? orderedColumns : customColumns.value
      const config = {
        files: fileList.map(f => ({
          id: f.id,
          name: f.name,
          tmp_path: f.tmp_path,
          sheets: f.sheets.filter(s => s.selected).map(s => ({ name: s.name })),
        })),
        file_order: fileOrder.value,
        do_merge: doMerge.value,
        add_source_col: doMerge.value && addSourceCol.value,
        source_col_name: sourceColName.value,
        col_order: effectiveColOrder,
        custom_columns: effectiveCustomColumns,
      }
      const result = await applyMerge(config)
      taskId.value = result.task_id
      await pollStatus()
    } catch (e) {
      setError(e.message)
    }
  }

  async function pollStatus() {
    for (let i = 0; i < 300; i++) {
      const data = await getMergeStatus(taskId.value)
      if (data.status === 'completed') {
        progress.value = { current: data.total, total: data.total }
        previewData.value = { columns: data.columns, rows: data.rows }
        // 只在用户未自定义文件名时才使用后端默认文件名
        if (!resultFilename.value || !resultFilename.value.trim()) {
          resultFilename.value = data.filename
        }
        status.value = 'preview'
        return
      } else if (data.status === 'error') {
        throw new Error(data.message || '处理出错')
      } else {
        progress.value = { current: data.current || 0, total: data.total || 1 }
      }
      await new Promise(r => setTimeout(r, 1000))
    }
    throw new Error('处理超时')
  }

  async function download() {
    if (!taskId.value) return
    const { blob } = await downloadMergeResult(taskId.value)
    // 优先使用用户设置的文件名
    let filename = resultFilename.value && resultFilename.value.trim()
      ? resultFilename.value.trim()
      : (doMerge.value ? '合并结果.xlsx' : '独立输出.xlsx')
    if (!filename.endsWith('.xlsx')) filename += '.xlsx'
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    a.click()
    URL.revokeObjectURL(url)
  }

  // 自动保存配置
  watch([addSourceCol, sourceColName, colOrder], () => {
    saveConfig({
      addSourceCol: addSourceCol.value,
      sourceColName: sourceColName.value,
      colOrder: colOrder.value,
    })
  }, { deep: true })

  return {
    files, fileOrder, sortedFiles, allColumns,
    doMerge, addSourceCol, sourceColName, colOrder, customColumns,
    taskId, status, progress, previewData, errorMsg, resultFilename,
    addFilesFromBackend, selectSheet, selectFirstSheet, updatePreviewFromFiles,
    selectedSheet, removeFile, moveFile, setError, clearAll,
    apply, download,
  }
})
