#!/usr/bin/env python3
"""Wrapper to start the data workbench"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))
import uvicorn
uvicorn.run('backend.main:app', host='0.0.0.0', port=8800, reload=False)
